import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type FontSize = 'sm' | 'md' | 'lg';
export type AppTheme = 'purple' | 'blue' | 'green';

interface SettingsCtx {
  fontSize: FontSize;
  theme: AppTheme;
  setFontSize: (s: FontSize) => void;
  setTheme: (t: AppTheme) => void;
}

const SettingsContext = createContext<SettingsCtx>({
  fontSize: 'md',
  theme: 'purple',
  setFontSize: () => {},
  setTheme: () => {},
});

const THEME_VARS: Record<AppTheme, Record<string, string>> = {
  purple: {
    '--primary': '270 100% 60%',
    '--secondary': '220 100% 50%',
    '--accent': '300 100% 55%',
    '--ring': '270 100% 60%',
  },
  blue: {
    '--primary': '215 100% 58%',
    '--secondary': '200 90% 45%',
    '--accent': '190 100% 50%',
    '--ring': '215 100% 58%',
  },
  green: {
    '--primary': '158 80% 42%',
    '--secondary': '170 75% 36%',
    '--accent': '142 76% 36%',
    '--ring': '158 80% 42%',
  },
};

const FONT_SCALE: Record<FontSize, string> = {
  sm: '14px',
  md: '16px',
  lg: '18px',
};

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [fontSize, setFontSizeState] = useState<FontSize>(
    () => (localStorage.getItem('bg_fontSize') as FontSize) || 'md'
  );
  const [theme, setThemeState] = useState<AppTheme>(
    () => (localStorage.getItem('bg_theme') as AppTheme) || 'purple'
  );

  const setFontSize = (s: FontSize) => {
    setFontSizeState(s);
    localStorage.setItem('bg_fontSize', s);
  };

  const setTheme = (t: AppTheme) => {
    setThemeState(t);
    localStorage.setItem('bg_theme', t);
  };

  useEffect(() => {
    document.documentElement.style.fontSize = FONT_SCALE[fontSize];
  }, [fontSize]);

  useEffect(() => {
    const vars = THEME_VARS[theme];
    const root = document.documentElement;
    Object.entries(vars).forEach(([k, v]) => root.style.setProperty(k, v));
  }, [theme]);

  return (
    <SettingsContext.Provider value={{ fontSize, theme, setFontSize, setTheme }}>
      {children}
    </SettingsContext.Provider>
  );
}

export const useSettings = () => useContext(SettingsContext);
