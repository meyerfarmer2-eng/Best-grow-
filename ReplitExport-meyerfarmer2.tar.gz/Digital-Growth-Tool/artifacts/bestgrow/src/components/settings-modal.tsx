import { motion, AnimatePresence } from 'framer-motion';
import { X, Type, Palette, MessageCircle, Check } from 'lucide-react';
import { useSettings, FontSize, AppTheme } from '@/context/settings-context';
import { Button } from './ui/button';

interface SettingsModalProps {
  open: boolean;
  onClose: () => void;
  onOpenChat: () => void;
}

const FONT_OPTIONS: { label: string; value: FontSize; preview: string }[] = [
  { label: 'Small', value: 'sm', preview: 'Aa' },
  { label: 'Medium', value: 'md', preview: 'Aa' },
  { label: 'Large', value: 'lg', preview: 'Aa' },
];

const THEME_OPTIONS: { label: string; value: AppTheme; from: string; to: string }[] = [
  { label: 'Purple', value: 'purple', from: '#7c3aed', to: '#3b82f6' },
  { label: 'Blue', value: 'blue', from: '#2563eb', to: '#06b6d4' },
  { label: 'Green', value: 'green', from: '#059669', to: '#10b981' },
];

export function SettingsModal({ open, onClose, onOpenChat }: SettingsModalProps) {
  const { fontSize, theme, setFontSize, setTheme } = useSettings();

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            key="sm-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            key="sm-panel"
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', stiffness: 300, damping: 28 }}
            className="fixed z-[61] inset-x-4 bottom-6 sm:inset-auto sm:right-6 sm:bottom-6 sm:w-96 bg-card border border-white/10 rounded-3xl shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-white/10">
              <h3 className="font-display font-bold text-white text-lg">Settings</h3>
              <button
                onClick={onClose}
                className="w-8 h-8 flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors text-muted-foreground hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-7">

              {/* Font Size */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <Type className="w-4 h-4 text-primary" /> Font Size
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {FONT_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => setFontSize(opt.value)}
                      className={`relative flex flex-col items-center justify-center gap-1.5 py-3 rounded-xl border transition-all ${
                        fontSize === opt.value
                          ? 'bg-primary/15 border-primary/50 text-white'
                          : 'bg-white/5 border-white/10 text-muted-foreground hover:border-white/20 hover:text-white'
                      }`}
                    >
                      {fontSize === opt.value && (
                        <div className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-primary flex items-center justify-center">
                          <Check className="w-2.5 h-2.5 text-white" />
                        </div>
                      )}
                      <span className={`font-bold leading-none ${
                        opt.value === 'sm' ? 'text-base' : opt.value === 'md' ? 'text-xl' : 'text-2xl'
                      }`}>{opt.preview}</span>
                      <span className="text-xs">{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Theme */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <Palette className="w-4 h-4 text-primary" /> Accent Theme
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {THEME_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => setTheme(opt.value)}
                      className={`relative flex flex-col items-center gap-2 py-4 rounded-xl border transition-all ${
                        theme === opt.value
                          ? 'border-white/40 bg-white/5'
                          : 'border-white/10 bg-white/3 hover:border-white/20'
                      }`}
                    >
                      {theme === opt.value && (
                        <div
                          className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full flex items-center justify-center"
                          style={{ background: `linear-gradient(135deg, ${opt.from}, ${opt.to})` }}
                        >
                          <Check className="w-2.5 h-2.5 text-white" />
                        </div>
                      )}
                      <div
                        className="w-8 h-8 rounded-full shadow-lg"
                        style={{ background: `linear-gradient(135deg, ${opt.from}, ${opt.to})` }}
                      />
                      <span className="text-xs font-medium text-muted-foreground">{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Support */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <MessageCircle className="w-4 h-4 text-primary" /> Support
                </div>
                <Button
                  variant="outline"
                  className="w-full gap-2 justify-start"
                  onClick={() => { onOpenChat(); onClose(); }}
                >
                  <MessageCircle className="w-4 h-4 text-primary" />
                  Chat with Support
                </Button>
              </div>

            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
