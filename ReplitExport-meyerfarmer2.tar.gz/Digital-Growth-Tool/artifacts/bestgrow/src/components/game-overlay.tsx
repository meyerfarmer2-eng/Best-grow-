import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Trophy } from 'lucide-react';
import { Button } from './ui/button';

interface GameOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export function GameOverlay({ isOpen, onClose }: GameOverlayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);

  const carXRef = useRef(140);
  const obstaclesRef = useRef<{ x: number; y: number }[]>([]);
  const scoreRef = useRef(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const gameOverRef = useRef(false);

  const startGame = () => {
    carXRef.current = 140;
    obstaclesRef.current = [];
    scoreRef.current = 0;
    gameOverRef.current = false;
    setScore(0);
    setIsGameOver(false);

    if (intervalRef.current) clearInterval(intervalRef.current);

    intervalRef.current = setInterval(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx || gameOverRef.current) return;

      ctx.clearRect(0, 0, 300, 400);

      // Road
      ctx.fillStyle = '#333';
      ctx.fillRect(100, 0, 100, 400);

      // Road lane markings
      ctx.strokeStyle = '#555';
      ctx.setLineDash([20, 20]);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(150, 0);
      ctx.lineTo(150, 400);
      ctx.stroke();
      ctx.setLineDash([]);

      // Car
      ctx.fillStyle = 'red';
      ctx.fillRect(carXRef.current, 350, 20, 30);
      // Car windshield
      ctx.fillStyle = '#88ccff';
      ctx.fillRect(carXRef.current + 3, 354, 14, 8);

      // Spawn obstacles
      if (Math.random() < 0.05) {
        obstaclesRef.current.push({ x: 100 + Math.random() * 80, y: 0 });
      }

      // Update & draw obstacles
      obstaclesRef.current = obstaclesRef.current.filter((o) => o.y < 420);
      for (const o of obstaclesRef.current) {
        o.y += 5;
        ctx.fillStyle = 'yellow';
        ctx.fillRect(o.x, o.y, 20, 20);

        // Collision
        if (
          o.y + 20 > 350 &&
          o.y < 380 &&
          o.x < carXRef.current + 20 &&
          o.x + 20 > carXRef.current
        ) {
          gameOverRef.current = true;
          setIsGameOver(true);
          if (intervalRef.current) clearInterval(intervalRef.current);

          ctx.fillStyle = 'rgba(0,0,0,0.65)';
          ctx.fillRect(0, 0, 300, 400);
          ctx.fillStyle = 'white';
          ctx.font = 'bold 24px Arial';
          ctx.textAlign = 'center';
          ctx.fillText('Game Over!', 150, 180);
          ctx.font = '16px Arial';
          ctx.fillText('Score: ' + scoreRef.current, 150, 215);
          ctx.fillText('Tap "Play Again" to retry', 150, 250);
          return;
        }
      }

      // Score
      scoreRef.current++;
      setScore(scoreRef.current);

      ctx.fillStyle = 'white';
      ctx.font = 'bold 14px Arial';
      ctx.textAlign = 'left';
      ctx.fillText('Score: ' + scoreRef.current, 8, 20);
    }, 50);
  };

  useEffect(() => {
    if (!isOpen) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      return;
    }
    startGame();

    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') carXRef.current = Math.max(100, carXRef.current - 10);
      if (e.key === 'ArrowRight') carXRef.current = Math.min(160, carXRef.current + 10);
    };
    window.addEventListener('keydown', handleKey);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      window.removeEventListener('keydown', handleKey);
    };
  }, [isOpen]);

  // Touch / swipe controls
  const touchStartX = useRef<number | null>(null);
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };
  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    if (dx < -20) carXRef.current = Math.max(100, carXRef.current - 20);
    if (dx > 20) carXRef.current = Math.min(160, carXRef.current + 20);
    touchStartX.current = null;
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-background/95 backdrop-blur-xl p-4"
        >
          <Button
            variant="glass"
            size="icon"
            onClick={onClose}
            className="absolute top-6 right-6 z-50 rounded-full"
          >
            <X className="w-6 h-6" />
          </Button>

          <div className="flex flex-col items-center gap-6">
            <div className="text-center">
              <h2 className="text-3xl font-display font-bold text-white mb-1">🚗 Road Dash</h2>
              <p className="text-muted-foreground text-sm">
                Arrow keys to steer · Swipe on mobile · Dodge the yellow cars!
              </p>
            </div>

            <div className="relative p-2 rounded-3xl bg-white/5 border border-white/10">
              <div className="absolute top-4 left-4 flex items-center gap-2 text-white font-bold z-10 bg-black/40 px-3 py-1 rounded-full backdrop-blur-md text-sm">
                <Trophy className="w-4 h-4 text-yellow-400" />
                {score}
              </div>
              <canvas
                ref={canvasRef}
                width="300"
                height="400"
                className="bg-[#1a1a2e] rounded-2xl touch-none"
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
              />
            </div>

            {isGameOver && (
              <Button
                onClick={startGame}
                className="bg-primary hover:bg-primary/90 text-white px-8 py-2 rounded-full font-bold"
              >
                Play Again
              </Button>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
