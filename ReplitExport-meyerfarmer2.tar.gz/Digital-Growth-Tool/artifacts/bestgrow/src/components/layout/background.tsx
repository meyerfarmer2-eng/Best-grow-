import React from 'react';

export function Background() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none -z-10">
      <div className="absolute inset-0 bg-background"></div>
      
      {/* Abstract blurred orbs for that "startup" vibe */}
      <div 
        className="ambient-orb w-[600px] h-[600px] top-[-100px] -left-[100px]"
        style={{ background: 'radial-gradient(circle, rgba(168,85,247,0.4) 0%, rgba(0,0,0,0) 70%)' }}
      />
      <div 
        className="ambient-orb w-[800px] h-[800px] top-[20%] -right-[200px]"
        style={{ 
          background: 'radial-gradient(circle, rgba(59,130,246,0.3) 0%, rgba(0,0,0,0) 70%)',
          animationDelay: '-5s' 
        }}
      />
      <div 
        className="ambient-orb w-[500px] h-[500px] bottom-[-100px] left-[20%]"
        style={{ 
          background: 'radial-gradient(circle, rgba(217,70,239,0.2) 0%, rgba(0,0,0,0) 70%)',
          animationDelay: '-10s' 
        }}
      />
      
      {/* Grid texture overlay */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMSIgY3k9IjEiIHI9IjEiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4wNSkiLz48L3N2Zz4=')] [mask-image:linear-gradient(to_bottom,black,transparent)] opacity-50" />
    </div>
  );
}
