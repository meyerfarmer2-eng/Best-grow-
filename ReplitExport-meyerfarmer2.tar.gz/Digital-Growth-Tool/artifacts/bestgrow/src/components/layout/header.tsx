import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  LogOut, X, LayoutDashboard, ShoppingBag, Home,
  UserPlus, Settings, Wallet
} from "lucide-react";
import { useState } from "react";
import { SettingsModal } from "@/components/settings-modal";

interface HeaderProps {
  user?: { name: string; email: string } | null;
  onLogout?: () => void;
  onOpenChat?: () => void;
}

export function Header({ user, onLogout, onOpenChat }: HeaderProps) {
  const [location] = useLocation();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const initial = user?.name ? user.name.charAt(0).toUpperCase() : '';

  const navLinks = user
    ? [
        { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { href: '/order', label: 'New Order', icon: ShoppingBag },
        { href: '/wallet', label: 'Wallet', icon: Wallet },
      ]
    : [
        { href: '/', label: 'Home', icon: Home },
        { href: '/auth', label: 'Sign Up', icon: UserPlus },
      ];

  const closeDrawer = () => setDrawerOpen(false);

  return (
    <>
      <header className="fixed top-0 w-full z-40 border-b border-white/5 bg-background/60 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-20 flex items-center justify-between">

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 group cursor-pointer" onClick={closeDrawer}>
            <div className="w-10 h-10 flex items-center justify-center overflow-hidden rounded-xl shadow-lg shadow-primary/20 group-hover:shadow-primary/40 transition-shadow">
              <img src="/favicon.svg" alt="BestGrow" className="w-full h-full object-cover" />
            </div>
            <h1 className="text-2xl font-bold font-display tracking-tight">
              Best<span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Grow</span>
            </h1>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`text-sm font-medium transition-colors hover:text-white ${
                  location === link.href ? 'text-white' : 'text-muted-foreground'
                }`}
              >
                {link.label}
              </Link>
            ))}

            {user ? (
              <div className="flex items-center gap-2 ml-2">
                <Link href="/dashboard" className="flex items-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl px-3 py-2 transition-colors">
                  <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-primary to-secondary flex items-center justify-center text-white text-xs font-bold">
                    {initial}
                  </div>
                  <span className="text-sm font-medium text-white">{user.name.split(' ')[0]}</span>
                </Link>
                <button
                  onClick={() => setSettingsOpen(true)}
                  className="p-2 text-muted-foreground hover:text-white transition-colors"
                  title="Settings"
                >
                  <Settings className="w-4 h-4" />
                </button>
                <button
                  onClick={onLogout}
                  className="p-2 text-muted-foreground hover:text-red-400 transition-colors"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 ml-2">
                <button
                  onClick={() => setSettingsOpen(true)}
                  className="p-2 text-muted-foreground hover:text-white transition-colors"
                  title="Settings"
                >
                  <Settings className="w-4 h-4" />
                </button>
                <Link href="/auth">
                  <motion.button
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    className="px-5 py-2.5 bg-gradient-to-r from-primary to-secondary text-white text-sm font-bold rounded-xl shadow-lg shadow-primary/20 hover:opacity-90 transition-opacity"
                  >
                    Get Started
                  </motion.button>
                </Link>
              </div>
            )}
          </nav>

          {/* Mobile — styled hamburger */}
          <button
            className="md:hidden flex flex-col justify-center items-center w-10 h-10 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors gap-[5px]"
            onClick={() => setDrawerOpen(true)}
            aria-label="Open menu"
          >
            <span style={{ width: '18px', height: '2px' }} className="bg-white rounded-full" />
            <span style={{ width: '13px', height: '2px' }} className="bg-white/50 rounded-full self-start ml-[5px]" />
            <span style={{ width: '18px', height: '2px' }} className="bg-white rounded-full" />
          </button>
        </div>
      </header>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {drawerOpen && (
          <>
            <motion.div
              key="backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
              onClick={closeDrawer}
            />
            <motion.div
              key="drawer"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="fixed top-0 right-0 z-50 h-full w-72 bg-card border-l border-white/10 shadow-2xl flex flex-col"
            >
              {/* Drawer header */}
              <div className="flex items-center justify-between px-5 h-20 border-b border-white/10 shrink-0">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 flex items-center justify-center rounded-lg overflow-hidden">
                    <img src="/favicon.svg" alt="BestGrow" className="w-full h-full object-cover" />
                  </div>
                  <span className="font-display font-bold text-white">BestGrow</span>
                </div>
                <button
                  onClick={closeDrawer}
                  className="w-9 h-9 flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors text-muted-foreground hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* User info */}
              {user && (
                <div className="px-5 py-4 border-b border-white/10 shrink-0">
                  <div className="flex items-center gap-3 bg-white/5 rounded-xl p-3 border border-white/10">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary to-secondary flex items-center justify-center text-white font-bold text-sm shrink-0">
                      {initial}
                    </div>
                    <div className="min-w-0">
                      <p className="text-white font-semibold text-sm truncate">{user.name}</p>
                      <p className="text-muted-foreground text-xs truncate">{user.email}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Nav links */}
              <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
                {navLinks.map((link) => {
                  const Icon = link.icon;
                  const active = location === link.href;
                  return (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={closeDrawer}
                      className={`flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                        active
                          ? 'bg-primary/15 text-white border border-primary/30'
                          : 'text-muted-foreground hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-primary' : ''}`} />
                      {link.label}
                    </Link>
                  );
                })}

                {/* Settings */}
                <button
                  onClick={() => { closeDrawer(); setTimeout(() => setSettingsOpen(true), 250); }}
                  className="flex items-center gap-3 w-full px-4 py-3.5 rounded-xl text-sm font-medium text-muted-foreground hover:text-white hover:bg-white/5 transition-all duration-200"
                >
                  <Settings className="w-4 h-4 shrink-0" />
                  Settings
                </button>
              </nav>

              {/* Bottom */}
              <div className="px-4 pb-8 pt-4 border-t border-white/10 shrink-0 space-y-2">
                {user ? (
                  <button
                    onClick={() => { onLogout?.(); closeDrawer(); }}
                    className="flex items-center gap-3 w-full px-4 py-3.5 rounded-xl text-sm font-medium text-red-400 hover:bg-red-400/10 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    Logout
                  </button>
                ) : (
                  <Link href="/auth" onClick={closeDrawer}>
                    <div className="w-full py-3.5 bg-gradient-to-r from-primary to-secondary text-white text-sm font-bold rounded-xl text-center shadow-lg shadow-primary/20">
                      Get Started
                    </div>
                  </Link>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Settings Modal */}
      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        onOpenChat={() => { onOpenChat?.(); }}
      />
    </>
  );
}
