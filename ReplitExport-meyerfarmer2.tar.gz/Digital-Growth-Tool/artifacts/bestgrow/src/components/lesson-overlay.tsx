import { motion, AnimatePresence } from 'framer-motion';
import { X, Lock, Sparkles, CheckCircle2, Copy, Building2, ArrowRight } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

export type LessonType = 'insta' | 'tiktok' | 'premium' | null;

interface LessonOverlayProps {
  type: LessonType;
  onClose: () => void;
}

type PremiumStep = 'locked' | 'payment' | 'pending';

export function LessonOverlay({ type, onClose }: LessonOverlayProps) {
  const { toast } = useToast();
  const [premiumStep, setPremiumStep] = useState<PremiumStep>('locked');
  const [senderName, setSenderName] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const copyAccount = () => {
    navigator.clipboard.writeText('9036377376');
    toast({ title: 'Copied!', description: 'Account number copied.' });
  };

  const handleSubmitProof = () => {
    if (!senderName.trim()) {
      toast({ title: 'Required', description: 'Please enter your name or payment reference.', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setPremiumStep('pending');
    }, 1000);
  };

  // Reset when overlay closes
  const handleClose = () => {
    setPremiumStep('locked');
    setSenderName('');
    onClose();
  };

  const lessonContent = {
    insta: {
      title: 'Instagram Growth Masterclass',
      icon: '📸',
      color: 'from-pink-500 to-orange-400',
      body: (
        <div className="space-y-4 text-left">
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <h4 className="font-bold text-white mb-2 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-400" /> Consistency is Key
            </h4>
            <p className="text-muted-foreground text-sm">Post at least once daily on your feed and 3–5 times on Stories to keep your audience engaged and trigger the algorithm.</p>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <h4 className="font-bold text-white mb-2 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-400" /> Reels Get the Most Reach
            </h4>
            <p className="text-muted-foreground text-sm">Reels have the highest organic reach. Use trending audio (under 10k uses) and hook viewers in the first 3 seconds.</p>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <h4 className="font-bold text-white mb-2 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-400" /> Hashtag Strategy
            </h4>
            <p className="text-muted-foreground text-sm">Use a mix of small (10k–100k), medium (100k–500k), and large (500k+) hashtags. Avoid using the same set every post.</p>
          </div>
        </div>
      ),
    },
    tiktok: {
      title: 'TikTok Viral Strategy',
      icon: '🎵',
      color: 'from-cyan-400 to-blue-600',
      body: (
        <div className="space-y-4 text-left">
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <h4 className="font-bold text-white mb-2 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-400" /> Ride Trends Early
            </h4>
            <p className="text-muted-foreground text-sm">Spend 15 minutes daily on your FYP spotting repeating sounds or formats. Act within 24 hours of a trend appearing.</p>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <h4 className="font-bold text-white mb-2 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-400" /> Hook in 2 Seconds
            </h4>
            <p className="text-muted-foreground text-sm">Use on-screen text immediately. Example: "3 secrets nobody tells you about [your niche]" forces a stop-scroll reflex.</p>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <h4 className="font-bold text-white mb-2 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-400" /> Post 2–3× Per Day
            </h4>
            <p className="text-muted-foreground text-sm">TikTok rewards volume. Each post gets its own chance at the FYP. Quantity plus quality is the winning formula.</p>
          </div>
        </div>
      ),
    },
  };

  if (!type) return null;

  return (
    <AnimatePresence>
      {type && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4 sm:p-6"
          onClick={handleClose}
        >
          <motion.div
            initial={{ scale: 0.95, y: 20, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.95, y: 20, opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 280 }}
            className="relative w-full max-w-lg bg-card border border-white/10 rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Colour band */}
            {type !== 'premium' && (
              <div className={`h-24 w-full bg-gradient-to-r ${lessonContent[type as 'insta' | 'tiktok'].color} opacity-20 absolute top-0 left-0`} />
            )}

            {/* Close button */}
            <button
              onClick={handleClose}
              className="absolute top-4 right-4 z-10 w-9 h-9 flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors text-muted-foreground hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Scrollable content */}
            <div className="relative p-6 sm:p-8 pt-10 overflow-y-auto">

              {/* Free lessons (insta / tiktok) */}
              {(type === 'insta' || type === 'tiktok') && (
                <>
                  <div className="text-5xl mb-4">{lessonContent[type].icon}</div>
                  <h2 className="text-2xl font-display font-bold text-white mb-6">{lessonContent[type].title}</h2>
                  {lessonContent[type].body}
                </>
              )}

              {/* Premium — LOCKED */}
              {type === 'premium' && premiumStep === 'locked' && (
                <div className="flex flex-col items-center text-center py-6 space-y-6">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center shadow-xl shadow-purple-500/30">
                    <Lock className="w-10 h-10 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-display font-bold text-white mb-2">Elite Monetization Strategy 💎</h2>
                    <p className="text-muted-foreground text-sm max-w-sm">Unlock the exact blueprint top creators use to turn 1,000 followers into ₦500k/month.</p>
                  </div>
                  <div className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-left space-y-2">
                    {['Automated DM funnel setup', 'Low-ticket digital product system', 'Content-to-sale conversion script', 'PDF guide + video walkthrough'].map((f) => (
                      <div key={f} className="flex items-center gap-2 text-sm text-white/80">
                        <Sparkles className="w-4 h-4 text-primary shrink-0" /> {f}
                      </div>
                    ))}
                  </div>
                  <Button
                    onClick={() => setPremiumStep('payment')}
                    variant="gradient"
                    size="lg"
                    className="w-full font-bold gap-2"
                  >
                    Unlock for ₦4,000 <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              )}

              {/* Premium — PAYMENT */}
              {type === 'premium' && premiumStep === 'payment' && (
                <div className="space-y-6">
                  <div>
                    <button onClick={() => setPremiumStep('locked')} className="text-muted-foreground hover:text-white text-sm mb-4 flex items-center gap-1 transition-colors">
                      ← Back
                    </button>
                    <h2 className="text-2xl font-display font-bold text-white mb-1">Complete Payment</h2>
                    <p className="text-muted-foreground text-sm">Transfer ₦4,000 to the account below, then confirm below.</p>
                  </div>

                  <div className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-4">
                    <div className="flex items-center gap-3 mb-2">
                      <Building2 className="w-5 h-5 text-primary" />
                      <span className="font-semibold text-white">Bank Transfer Details</span>
                    </div>
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Bank</span>
                        <span className="text-white font-medium">Opay</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Account Name</span>
                        <span className="text-white font-medium">Davidbest Johnson Ebong</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Account No.</span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-lg font-bold text-primary tracking-wider">9036377376</span>
                          <button onClick={copyAccount} className="p-1.5 hover:bg-white/10 rounded-lg transition-colors">
                            <Copy className="w-3.5 h-3.5 text-muted-foreground hover:text-white" />
                          </button>
                        </div>
                      </div>
                      <div className="flex justify-between border-t border-white/10 pt-3 font-bold">
                        <span className="text-muted-foreground">Amount</span>
                        <span className="text-white text-base">₦4,000</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-sm font-medium text-muted-foreground block">Your Name / Payment Reference</label>
                    <Input
                      placeholder="e.g. John Doe"
                      value={senderName}
                      onChange={(e) => setSenderName(e.target.value)}
                    />
                    <Button
                      onClick={handleSubmitProof}
                      disabled={submitting}
                      variant="gradient"
                      className="w-full h-12 font-bold"
                    >
                      {submitting ? (
                        <span className="flex items-center gap-2">
                          <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          Submitting...
                        </span>
                      ) : 'I Have Paid — Submit for Review'}
                    </Button>
                  </div>
                </div>
              )}

              {/* Premium — PENDING */}
              {type === 'premium' && premiumStep === 'pending' && (
                <div className="flex flex-col items-center text-center py-8 space-y-6">
                  <div className="w-20 h-20 rounded-full bg-yellow-400/10 border border-yellow-400/30 flex items-center justify-center">
                    <CheckCircle2 className="w-10 h-10 text-yellow-400" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-display font-bold text-white mb-2">Payment Under Review</h2>
                    <p className="text-muted-foreground text-sm max-w-sm">
                      Thank you! Your payment proof has been submitted. Once verified (usually within a few minutes), your premium content will be unlocked automatically.
                    </p>
                  </div>
                  <div className="w-full bg-yellow-400/5 border border-yellow-400/20 rounded-xl p-4 text-sm text-yellow-300">
                    We'll notify you as soon as your access is granted.
                  </div>
                  <Button variant="outline" onClick={handleClose} className="w-full">
                    Close
                  </Button>
                </div>
              )}

            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
