import { useState, useRef, useEffect, useCallback } from 'react';
import { Trophy, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';
import { useToast } from '@/hooks/use-toast';

function getCoins(): number {
  return parseInt(localStorage.getItem('bestgrow_coins') || '0');
}
function addCoins(n: number) {
  const current = getCoins();
  localStorage.setItem('bestgrow_coins', String(current + n));
}
function getHighScore(game: string): number {
  const raw = localStorage.getItem('bestgrow_highscores');
  const obj = raw ? JSON.parse(raw) : {};
  return obj[game] || 0;
}
function setHighScore(game: string, score: number) {
  const raw = localStorage.getItem('bestgrow_highscores');
  const obj = raw ? JSON.parse(raw) : {};
  obj[game] = score;
  localStorage.setItem('bestgrow_highscores', JSON.stringify(obj));
}

/* ─── CAR RACE GAME ──────────────────────────────────────── */
function CarRaceGame({ onCoinEarned }: { onCoinEarned: (n: number) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [highScore, setHS] = useState(() => getHighScore('car'));
  const [isOver, setIsOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [newHS, setNewHS] = useState(false);
  const { toast } = useToast();

  const carXRef = useRef(138);
  const obstaclesRef = useRef<{ x: number; y: number; w: number; h: number; color: string }[]>([]);
  const scoreRef = useRef(0);
  const frameRef = useRef<number | null>(null);
  const gameOverRef = useRef(false);
  const keysRef = useRef<Set<string>>(new Set());
  const laneMarkRef = useRef(0);

  const CANVAS_W = 300, CANVAS_H = 450;
  const ROAD_X = 75, ROAD_W = 150;
  const CAR_W = 28, CAR_H = 44;
  const CAR_Y = CANVAS_H - 80;

  const stopGame = useCallback(() => {
    if (frameRef.current) cancelAnimationFrame(frameRef.current);
    frameRef.current = null;
  }, []);

  const startGame = useCallback(() => {
    carXRef.current = ROAD_X + ROAD_W / 2 - CAR_W / 2;
    obstaclesRef.current = [];
    scoreRef.current = 0;
    laneMarkRef.current = 0;
    gameOverRef.current = false;
    keysRef.current.clear();
    setScore(0);
    setIsOver(false);
    setNewHS(false);
    setStarted(true);
    stopGame();

    let frameCount = 0;
    const loop = () => {
      if (gameOverRef.current) return;
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      frameCount++;
      const speed = 3 + scoreRef.current * 0.003;

      // Move car with keys
      if (keysRef.current.has('ArrowLeft') || keysRef.current.has('a') || keysRef.current.has('A')) {
        carXRef.current = Math.max(ROAD_X + 4, carXRef.current - 4);
      }
      if (keysRef.current.has('ArrowRight') || keysRef.current.has('d') || keysRef.current.has('D')) {
        carXRef.current = Math.min(ROAD_X + ROAD_W - CAR_W - 4, carXRef.current + 4);
      }

      // Background
      ctx.fillStyle = '#111827';
      ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

      // Grass
      ctx.fillStyle = '#14532d';
      ctx.fillRect(0, 0, ROAD_X, CANVAS_H);
      ctx.fillRect(ROAD_X + ROAD_W, 0, CANVAS_W - ROAD_X - ROAD_W, CANVAS_H);

      // Road
      ctx.fillStyle = '#374151';
      ctx.fillRect(ROAD_X, 0, ROAD_W, CANVAS_H);

      // Lane markings (animated)
      laneMarkRef.current = (laneMarkRef.current + speed) % 60;
      ctx.strokeStyle = '#6b7280';
      ctx.setLineDash([30, 30]);
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(ROAD_X + ROAD_W / 2, -laneMarkRef.current);
      ctx.lineTo(ROAD_X + ROAD_W / 2, CANVAS_H + 30);
      ctx.stroke();
      ctx.setLineDash([]);

      // Road edges
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(ROAD_X, 0); ctx.lineTo(ROAD_X, CANVAS_H);
      ctx.moveTo(ROAD_X + ROAD_W, 0); ctx.lineTo(ROAD_X + ROAD_W, CANVAS_H);
      ctx.stroke();

      // Spawn obstacles
      if (frameCount % 80 === 0) {
        const colors = ['#ef4444', '#f97316', '#3b82f6', '#8b5cf6'];
        const ox = ROAD_X + 8 + Math.random() * (ROAD_W - CAR_W - 16);
        obstaclesRef.current.push({ x: ox, y: -50, w: CAR_W, h: CAR_H, color: colors[Math.floor(Math.random() * colors.length)] });
      }

      // Draw & move obstacles
      obstaclesRef.current = obstaclesRef.current.filter(o => o.y < CANVAS_H + 60);
      for (const o of obstaclesRef.current) {
        o.y += speed;
        // Enemy car body
        ctx.fillStyle = o.color;
        ctx.fillRect(o.x, o.y, o.w, o.h);
        ctx.fillStyle = 'rgba(0,0,0,0.4)';
        ctx.fillRect(o.x + 4, o.y + 8, o.w - 8, 12);
        ctx.fillRect(o.x + 4, o.y + o.h - 18, o.w - 8, 10);
        // Wheels
        ctx.fillStyle = '#1f2937';
        ctx.fillRect(o.x - 4, o.y + 6, 6, 10);
        ctx.fillRect(o.x + o.w - 2, o.y + 6, 6, 10);
        ctx.fillRect(o.x - 4, o.y + o.h - 16, 6, 10);
        ctx.fillRect(o.x + o.w - 2, o.y + o.h - 16, 6, 10);

        // Collision
        if (o.y + o.h > CAR_Y + 6 && o.y < CAR_Y + CAR_H - 6 &&
          o.x + o.w > carXRef.current + 4 && o.x < carXRef.current + CAR_W - 4) {
          gameOverRef.current = true;
          setIsOver(true);
          const finalScore = scoreRef.current;
          setScore(finalScore);
          const hs = getHighScore('car');
          if (finalScore > hs) {
            setHighScore('car', finalScore);
            setHS(finalScore);
            setNewHS(true);
            const earned = Math.max(5, Math.floor(finalScore / 50));
            addCoins(earned);
            onCoinEarned(earned);
            toast({ title: `🏆 New High Score! +${earned} coins!`, description: `You beat your record with ${finalScore} points!` });
          }
          // Game over screen
          ctx.fillStyle = 'rgba(0,0,0,0.75)';
          ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
          ctx.fillStyle = '#fff';
          ctx.font = 'bold 24px Arial'; ctx.textAlign = 'center';
          ctx.fillText('GAME OVER! 💥', CANVAS_W / 2, 180);
          ctx.font = '16px Arial';
          ctx.fillText('Score: ' + finalScore, CANVAS_W / 2, 215);
          ctx.fillText('Tap Play Again', CANVAS_W / 2, 250);
          stopGame();
          return;
        }
      }

      // Player car
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(carXRef.current, CAR_Y, CAR_W, CAR_H);
      ctx.fillStyle = '#86efac';
      ctx.fillRect(carXRef.current + 4, CAR_Y + 6, CAR_W - 8, 14);
      ctx.fillRect(carXRef.current + 4, CAR_Y + CAR_H - 18, CAR_W - 8, 10);
      ctx.fillStyle = '#1f2937';
      ctx.fillRect(carXRef.current - 4, CAR_Y + 6, 6, 10);
      ctx.fillRect(carXRef.current + CAR_W - 2, CAR_Y + 6, 6, 10);
      ctx.fillRect(carXRef.current - 4, CAR_Y + CAR_H - 16, 6, 10);
      ctx.fillRect(carXRef.current + CAR_W - 2, CAR_Y + CAR_H - 16, 6, 10);

      // HUD
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(6, 6, 110, 28);
      ctx.fillStyle = '#facc15';
      ctx.font = 'bold 14px Arial'; ctx.textAlign = 'left';
      ctx.fillText('⭐ ' + scoreRef.current, 14, 25);

      scoreRef.current++;
      setScore(scoreRef.current);

      frameRef.current = requestAnimationFrame(loop);
    };
    frameRef.current = requestAnimationFrame(loop);
  }, [stopGame, onCoinEarned, toast]);

  useEffect(() => {
    const down = (e: KeyboardEvent) => { keysRef.current.add(e.key); };
    const up = (e: KeyboardEvent) => { keysRef.current.delete(e.key); };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      stopGame();
    };
  }, [stopGame]);

  const holdLeft = useRef<ReturnType<typeof setInterval> | null>(null);
  const holdRight = useRef<ReturnType<typeof setInterval> | null>(null);

  const pressLeft = () => { if (!started || isOver) return; holdLeft.current = setInterval(() => { carXRef.current = Math.max(ROAD_X + 4, carXRef.current - 6); }, 50); };
  const pressRight = () => { if (!started || isOver) return; holdRight.current = setInterval(() => { carXRef.current = Math.min(ROAD_X + ROAD_W - CAR_W - 4, carXRef.current + 6); }, 50); };
  const releaseLeft = () => { if (holdLeft.current) clearInterval(holdLeft.current); };
  const releaseRight = () => { if (holdRight.current) clearInterval(holdRight.current); };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center gap-6 text-sm">
        <span className="flex items-center gap-1 text-white font-bold"><Trophy className="w-4 h-4 text-yellow-400" /> {score}</span>
        <span className="text-muted-foreground">Best: <span className="text-white font-semibold">{highScore}</span></span>
        {newHS && <span className="text-yellow-400 font-bold animate-pulse">🏆 NEW BEST!</span>}
      </div>
      <div className="relative border-2 border-white/10 rounded-2xl overflow-hidden">
        <canvas ref={canvasRef} width={CANVAS_W} height={CANVAS_H} style={{ display: 'block', background: '#111827' }} />
        {!started && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 gap-3">
            <p className="text-4xl">🚗</p>
            <p className="text-white font-bold text-lg">Car Race</p>
            <p className="text-muted-foreground text-sm text-center px-4">Arrow keys or buttons below · Dodge enemy cars!</p>
          </div>
        )}
      </div>
      <div className="flex items-center gap-4">
        <button
          onMouseDown={pressLeft} onMouseUp={releaseLeft} onTouchStart={pressLeft} onTouchEnd={releaseLeft}
          className="w-16 h-16 bg-white/10 border border-white/20 rounded-2xl flex items-center justify-center text-white active:bg-white/20 select-none"
        >
          <ChevronLeft className="w-8 h-8" />
        </button>
        <Button onClick={startGame} variant="gradient" className="px-8 font-bold">
          {isOver ? 'Play Again' : started ? 'Restart' : '▶ Start'}
        </Button>
        <button
          onMouseDown={pressRight} onMouseUp={releaseRight} onTouchStart={pressRight} onTouchEnd={releaseRight}
          className="w-16 h-16 bg-white/10 border border-white/20 rounded-2xl flex items-center justify-center text-white active:bg-white/20 select-none"
        >
          <ChevronRight className="w-8 h-8" />
        </button>
      </div>
    </div>
  );
}

/* ─── SNAKE GAME ──────────────────────────────────────────── */
function SnakeGame({ onCoinEarned }: { onCoinEarned: (n: number) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [highScore, setHS] = useState(() => getHighScore('snake'));
  const [isOver, setIsOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [newHS, setNewHS] = useState(false);
  const { toast } = useToast();

  const CELL = 20, COLS = 15, ROWS = 15;
  const W = CELL * COLS, H = CELL * ROWS;

  const snakeRef = useRef<{ x: number; y: number }[]>([]);
  const dirRef = useRef<{ x: number; y: number }>({ x: 1, y: 0 });
  const nextDirRef = useRef<{ x: number; y: number }>({ x: 1, y: 0 });
  const foodRef = useRef<{ x: number; y: number }>({ x: 7, y: 5 });
  const scoreRef = useRef(0);
  const frameRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const gameOverRef = useRef(false);

  const placeFood = () => {
    let pos: { x: number; y: number };
    do { pos = { x: Math.floor(Math.random() * COLS), y: Math.floor(Math.random() * ROWS) }; }
    while (snakeRef.current.some(s => s.x === pos.x && s.y === pos.y));
    foodRef.current = pos;
  };

  const stopGame = useCallback(() => {
    if (frameRef.current) clearInterval(frameRef.current);
    frameRef.current = null;
  }, []);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, W, H);

    // Grid
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= COLS; i++) {
      ctx.beginPath(); ctx.moveTo(i * CELL, 0); ctx.lineTo(i * CELL, H); ctx.stroke();
    }
    for (let i = 0; i <= ROWS; i++) {
      ctx.beginPath(); ctx.moveTo(0, i * CELL); ctx.lineTo(W, i * CELL); ctx.stroke();
    }

    // Food
    const f = foodRef.current;
    ctx.fillStyle = '#f43f5e';
    ctx.beginPath();
    ctx.arc(f.x * CELL + CELL / 2, f.y * CELL + CELL / 2, CELL / 2 - 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#4ade80';
    ctx.fillRect(f.x * CELL + CELL / 2 - 1, f.y * CELL + 2, 3, 5);

    // Snake
    snakeRef.current.forEach((seg, i) => {
      const ratio = 1 - i / snakeRef.current.length;
      ctx.fillStyle = i === 0 ? '#22c55e' : `rgba(34,${Math.floor(160 + ratio * 60)},80,${0.5 + ratio * 0.5})`;
      ctx.fillRect(seg.x * CELL + 1, seg.y * CELL + 1, CELL - 2, CELL - 2);
      if (i === 0) {
        ctx.fillStyle = '#fff';
        const ex = dirRef.current.x, ey = dirRef.current.y;
        ctx.fillRect(seg.x * CELL + 4 + ex * 3 + ey * 3, seg.y * CELL + 4 + ey * 3 + ex * 3, 4, 4);
        ctx.fillRect(seg.x * CELL + CELL - 10 + ex * 3 - ey * 3, seg.y * CELL + 4 + ey * 3 - ex * 3, 4, 4);
      }
    });

    // Score HUD
    ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(4, 4, 80, 24);
    ctx.fillStyle = '#22c55e'; ctx.font = 'bold 13px Arial'; ctx.textAlign = 'left';
    ctx.fillText('🍎 ' + scoreRef.current, 10, 21);
  }, [W, H]);

  const startGame = useCallback(() => {
    snakeRef.current = [{ x: 7, y: 7 }, { x: 6, y: 7 }, { x: 5, y: 7 }];
    dirRef.current = { x: 1, y: 0 };
    nextDirRef.current = { x: 1, y: 0 };
    scoreRef.current = 0;
    gameOverRef.current = false;
    setScore(0);
    setIsOver(false);
    setNewHS(false);
    setStarted(true);
    placeFood();
    stopGame();
    draw();

    frameRef.current = setInterval(() => {
      if (gameOverRef.current) return;
      dirRef.current = nextDirRef.current;
      const head = { x: snakeRef.current[0].x + dirRef.current.x, y: snakeRef.current[0].y + dirRef.current.y };

      if (head.x < 0 || head.x >= COLS || head.y < 0 || head.y >= ROWS ||
        snakeRef.current.some(s => s.x === head.x && s.y === head.y)) {
        gameOverRef.current = true;
        setIsOver(true);
        const fs = scoreRef.current;
        setScore(fs);
        const hs = getHighScore('snake');
        if (fs > hs) {
          setHighScore('snake', fs);
          setHS(fs);
          setNewHS(true);
          const earned = Math.max(5, fs * 2);
          addCoins(earned);
          onCoinEarned(earned);
          toast({ title: `🏆 New High Score! +${earned} coins!`, description: `Snake master! ${fs} apples eaten!` });
        }
        const canvas = canvasRef.current; if (!canvas) return;
        const ctx = canvas.getContext('2d'); if (!ctx) return;
        ctx.fillStyle = 'rgba(0,0,0,0.75)'; ctx.fillRect(0, 0, W, H);
        ctx.fillStyle = '#fff'; ctx.font = 'bold 22px Arial'; ctx.textAlign = 'center';
        ctx.fillText('Game Over! 🐍', W / 2, H / 2 - 30);
        ctx.font = '15px Arial';
        ctx.fillText('Score: ' + fs, W / 2, H / 2 + 5);
        ctx.fillText('Tap Play Again', W / 2, H / 2 + 35);
        stopGame();
        return;
      }

      snakeRef.current = [head, ...snakeRef.current];
      if (head.x === foodRef.current.x && head.y === foodRef.current.y) {
        scoreRef.current++;
        setScore(scoreRef.current);
        placeFood();
      } else {
        snakeRef.current.pop();
      }
      draw();
    }, 150);
  }, [stopGame, draw, onCoinEarned, toast, W, H]);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const d = dirRef.current;
      if ((e.key === 'ArrowUp' || e.key === 'w') && d.y !== 1) nextDirRef.current = { x: 0, y: -1 };
      if ((e.key === 'ArrowDown' || e.key === 's') && d.y !== -1) nextDirRef.current = { x: 0, y: 1 };
      if ((e.key === 'ArrowLeft' || e.key === 'a') && d.x !== 1) nextDirRef.current = { x: -1, y: 0 };
      if ((e.key === 'ArrowRight' || e.key === 'd') && d.x !== -1) nextDirRef.current = { x: 1, y: 0 };
      if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)) e.preventDefault();
    };
    window.addEventListener('keydown', down);
    return () => { window.removeEventListener('keydown', down); stopGame(); };
  }, [stopGame]);

  const swipeStart = useRef<{ x: number; y: number } | null>(null);
  const handleTouchStart = (e: React.TouchEvent) => { swipeStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }; };
  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!swipeStart.current) return;
    const dx = e.changedTouches[0].clientX - swipeStart.current.x;
    const dy = e.changedTouches[0].clientY - swipeStart.current.y;
    const d = dirRef.current;
    if (Math.abs(dx) > Math.abs(dy)) {
      if (dx > 20 && d.x !== -1) nextDirRef.current = { x: 1, y: 0 };
      if (dx < -20 && d.x !== 1) nextDirRef.current = { x: -1, y: 0 };
    } else {
      if (dy > 20 && d.y !== -1) nextDirRef.current = { x: 0, y: 1 };
      if (dy < -20 && d.y !== 1) nextDirRef.current = { x: 0, y: -1 };
    }
    swipeStart.current = null;
  };

  const dpad = (dx: number, dy: number) => {
    const d = dirRef.current;
    if (dx === 1 && d.x !== -1) nextDirRef.current = { x: 1, y: 0 };
    if (dx === -1 && d.x !== 1) nextDirRef.current = { x: -1, y: 0 };
    if (dy === 1 && d.y !== -1) nextDirRef.current = { x: 0, y: 1 };
    if (dy === -1 && d.y !== 1) nextDirRef.current = { x: 0, y: -1 };
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center gap-6 text-sm">
        <span className="flex items-center gap-1 text-white font-bold"><Trophy className="w-4 h-4 text-yellow-400" /> {score}</span>
        <span className="text-muted-foreground">Best: <span className="text-white font-semibold">{highScore}</span></span>
        {newHS && <span className="text-yellow-400 font-bold animate-pulse">🏆 NEW BEST!</span>}
      </div>
      <div className="relative border-2 border-white/10 rounded-2xl overflow-hidden touch-none"
        onTouchStart={handleTouchStart} onTouchEnd={handleTouchEnd}>
        <canvas ref={canvasRef} width={W} height={H} style={{ display: 'block' }} />
        {!started && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 gap-3">
            <p className="text-4xl">🐍</p>
            <p className="text-white font-bold text-lg">Snake</p>
            <p className="text-muted-foreground text-sm text-center px-4">Arrow keys or D-pad · Eat the apples!</p>
          </div>
        )}
      </div>
      <div className="grid grid-cols-3 gap-2">
        <div />
        <button onClick={() => dpad(0, -1)} className="w-14 h-14 bg-white/10 border border-white/20 rounded-xl flex items-center justify-center text-white text-xl active:bg-white/20">▲</button>
        <div />
        <button onClick={() => dpad(-1, 0)} className="w-14 h-14 bg-white/10 border border-white/20 rounded-xl flex items-center justify-center text-white text-xl active:bg-white/20">◀</button>
        <Button onClick={startGame} variant="gradient" className="w-14 h-14 p-0 font-bold text-xs">
          {isOver ? '↺' : started ? '↺' : '▶'}
        </Button>
        <button onClick={() => dpad(1, 0)} className="w-14 h-14 bg-white/10 border border-white/20 rounded-xl flex items-center justify-center text-white text-xl active:bg-white/20">▶</button>
        <div />
        <button onClick={() => dpad(0, 1)} className="w-14 h-14 bg-white/10 border border-white/20 rounded-xl flex items-center justify-center text-white text-xl active:bg-white/20">▼</button>
        <div />
      </div>
    </div>
  );
}

/* ─── NINJA FLYER GAME ────────────────────────────────────── */
function NinjaFlyerGame({ onCoinEarned }: { onCoinEarned: (n: number) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [highScore, setHS] = useState(() => getHighScore('ninja'));
  const [isOver, setIsOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [newHS, setNewHS] = useState(false);
  const { toast } = useToast();

  const W = 300, H = 450;
  const NINJA_X = 70, NINJA_R = 18;
  const PIPE_W = 48, PIPE_GAP = 130, PIPE_SPEED = 2.5;

  const ninjaY = useRef(H / 2);
  const vy = useRef(0);
  const pipes = useRef<{ x: number; gapY: number; passed: boolean }[]>([]);
  const scoreRef = useRef(0);
  const frameRef = useRef<number | null>(null);
  const gameOverRef = useRef(false);
  const bgStars = useRef<{ x: number; y: number; r: number }[]>([]);

  const stopGame = useCallback(() => {
    if (frameRef.current) cancelAnimationFrame(frameRef.current);
    frameRef.current = null;
  }, []);

  const flap = useCallback(() => {
    if (gameOverRef.current || !frameRef.current) return;
    vy.current = -7;
  }, []);

  useEffect(() => {
    bgStars.current = Array.from({ length: 30 }, () => ({
      x: Math.random() * W, y: Math.random() * H, r: Math.random() * 1.5 + 0.5,
    }));
  }, []);

  const startGame = useCallback(() => {
    ninjaY.current = H / 2;
    vy.current = 0;
    pipes.current = [];
    scoreRef.current = 0;
    gameOverRef.current = false;
    setScore(0);
    setIsOver(false);
    setNewHS(false);
    setStarted(true);
    stopGame();

    let frameCount = 0;
    const GRAVITY = 0.38;

    const loop = () => {
      if (gameOverRef.current) return;
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      frameCount++;
      vy.current += GRAVITY;
      ninjaY.current += vy.current;

      // Spawn pipes
      if (frameCount % 110 === 0) {
        const gapY = 120 + Math.random() * (H - 280);
        pipes.current.push({ x: W + PIPE_W, gapY, passed: false });
      }

      // Background
      ctx.fillStyle = '#0f0a1e';
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = '#fff';
      for (const s of bgStars.current) {
        ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2); ctx.fill();
      }

      // Ground & ceiling
      ctx.fillStyle = '#1e1040';
      ctx.fillRect(0, 0, W, 20);
      ctx.fillRect(0, H - 20, W, 20);
      ctx.strokeStyle = '#7c3aed'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0, 20); ctx.lineTo(W, 20); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, H - 20); ctx.lineTo(W, H - 20); ctx.stroke();

      // Pipes
      pipes.current = pipes.current.filter(p => p.x > -PIPE_W - 10);
      for (const p of pipes.current) {
        p.x -= PIPE_SPEED + scoreRef.current * 0.04;
        const topH = p.gapY;
        const botY = p.gapY + PIPE_GAP;
        const botH = H - 20 - botY;

        // Top pipe
        const gTop = ctx.createLinearGradient(p.x, 0, p.x + PIPE_W, 0);
        gTop.addColorStop(0, '#6d28d9'); gTop.addColorStop(1, '#a855f7');
        ctx.fillStyle = gTop;
        ctx.fillRect(p.x, 20, PIPE_W, topH - 20);
        ctx.fillStyle = '#7c3aed';
        ctx.fillRect(p.x - 5, topH - 20, PIPE_W + 10, 20);

        // Bottom pipe
        const gBot = ctx.createLinearGradient(p.x, 0, p.x + PIPE_W, 0);
        gBot.addColorStop(0, '#6d28d9'); gBot.addColorStop(1, '#a855f7');
        ctx.fillStyle = gBot;
        ctx.fillRect(p.x, botY + 20, PIPE_W, botH);
        ctx.fillStyle = '#7c3aed';
        ctx.fillRect(p.x - 5, botY, PIPE_W + 10, 20);

        if (!p.passed && p.x + PIPE_W < NINJA_X) {
          p.passed = true;
          scoreRef.current++;
          setScore(scoreRef.current);
        }

        // Collision
        if (NINJA_X + NINJA_R > p.x + 4 && NINJA_X - NINJA_R < p.x + PIPE_W - 4) {
          if (ninjaY.current - NINJA_R < topH || ninjaY.current + NINJA_R > botY) {
            gameOverRef.current = true;
          }
        }
      }

      // Floor/ceiling collision
      if (ninjaY.current + NINJA_R >= H - 20 || ninjaY.current - NINJA_R <= 20) {
        gameOverRef.current = true;
      }

      // Draw ninja
      const angle = Math.min(Math.max(vy.current * 0.06, -0.5), 0.8);
      ctx.save();
      ctx.translate(NINJA_X, ninjaY.current);
      ctx.rotate(angle);
      // Body
      ctx.fillStyle = '#1f2937';
      ctx.beginPath(); ctx.arc(0, 0, NINJA_R, 0, Math.PI * 2); ctx.fill();
      // Headband
      ctx.strokeStyle = '#ef4444'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(-NINJA_R, -4); ctx.lineTo(NINJA_R, -4); ctx.stroke();
      // Eyes
      ctx.fillStyle = '#fff';
      ctx.fillRect(4, -9, 10, 6);
      ctx.fillStyle = '#000';
      ctx.fillRect(7, -8, 4, 4);
      // Star
      ctx.fillStyle = '#facc15';
      ctx.font = 'bold 12px Arial'; ctx.textAlign = 'center';
      ctx.fillText('✦', 0, 6);
      ctx.restore();

      if (gameOverRef.current) {
        setIsOver(true);
        const fs = scoreRef.current;
        const hs = getHighScore('ninja');
        if (fs > hs) {
          setHighScore('ninja', fs);
          setHS(fs);
          setNewHS(true);
          const earned = Math.max(5, fs * 3);
          addCoins(earned);
          onCoinEarned(earned);
          toast({ title: `🏆 New High Score! +${earned} coins!`, description: `Ninja master! ${fs} gates cleared!` });
        }
        ctx.fillStyle = 'rgba(0,0,0,0.75)'; ctx.fillRect(0, 0, W, H);
        ctx.fillStyle = '#fff'; ctx.font = 'bold 24px Arial'; ctx.textAlign = 'center';
        ctx.fillText('Ninja Down! 🥷', W / 2, H / 2 - 30);
        ctx.font = '16px Arial';
        ctx.fillText('Score: ' + fs, W / 2, H / 2 + 5);
        ctx.fillText('Tap Play Again', W / 2, H / 2 + 35);
        stopGame();
        return;
      }

      // HUD
      ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(W / 2 - 35, 25, 70, 26);
      ctx.fillStyle = '#e879f9'; ctx.font = 'bold 15px Arial'; ctx.textAlign = 'center';
      ctx.fillText('🥷 ' + scoreRef.current, W / 2, 43);

      frameRef.current = requestAnimationFrame(loop);
    };
    frameRef.current = requestAnimationFrame(loop);
  }, [stopGame, onCoinEarned, toast, H, W]);

  useEffect(() => {
    const down = (e: KeyboardEvent) => { if (e.code === 'Space') { e.preventDefault(); flap(); } };
    window.addEventListener('keydown', down);
    return () => { window.removeEventListener('keydown', down); stopGame(); };
  }, [stopGame, flap]);

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center gap-6 text-sm">
        <span className="flex items-center gap-1 text-white font-bold"><Trophy className="w-4 h-4 text-yellow-400" /> {score}</span>
        <span className="text-muted-foreground">Best: <span className="text-white font-semibold">{highScore}</span></span>
        {newHS && <span className="text-yellow-400 font-bold animate-pulse">🏆 NEW BEST!</span>}
      </div>
      <div className="relative border-2 border-white/10 rounded-2xl overflow-hidden cursor-pointer"
        onClick={started && !isOver ? flap : undefined}>
        <canvas ref={canvasRef} width={W} height={H} style={{ display: 'block', background: '#0f0a1e' }} />
        {!started && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 gap-3">
            <p className="text-4xl">🥷</p>
            <p className="text-white font-bold text-lg">Ninja Flyer</p>
            <p className="text-muted-foreground text-sm text-center px-4">Tap or press Space to fly · Pass the gates!</p>
          </div>
        )}
      </div>
      <div className="flex items-center gap-4">
        <Button onClick={startGame} variant="gradient" className="px-8 font-bold">
          {isOver ? 'Play Again' : started ? 'Restart' : '▶ Start'}
        </Button>
        {started && !isOver && (
          <Button onClick={flap} variant="glass" className="px-6">
            🥷 Flap!
          </Button>
        )}
      </div>
      {started && !isOver && <p className="text-muted-foreground text-xs">Tap the canvas or press Space to fly</p>}
    </div>
  );
}

/* ─── GAMES SECTION (main export) ────────────────────────── */
type GameId = 'car' | 'snake' | 'ninja';

const GAME_TABS: { id: GameId; label: string; emoji: string; desc: string }[] = [
  { id: 'car', label: 'Car Race', emoji: '🚗', desc: 'Dodge enemy cars' },
  { id: 'snake', label: 'Snake', emoji: '🐍', desc: 'Eat the apples' },
  { id: 'ninja', label: 'Ninja Flyer', emoji: '🥷', desc: 'Fly through gates' },
];

export function GamesSection() {
  const [activeGame, setActiveGame] = useState<GameId>('car');
  const [totalCoins, setTotalCoins] = useState(getCoins);

  const handleCoinEarned = (n: number) => {
    setTotalCoins(getCoins());
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-display font-bold text-white">🎮 Games</h2>
          <p className="text-muted-foreground text-sm">Beat your high score to earn coins!</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-yellow-400/10 border border-yellow-400/30 rounded-xl">
          <Trophy className="w-4 h-4 text-yellow-400" />
          <span className="text-yellow-300 font-bold">{totalCoins}</span>
          <span className="text-yellow-400/70 text-sm">coins</span>
        </div>
      </div>

      <div className="flex gap-2 flex-wrap">
        {GAME_TABS.map(g => (
          <button
            key={g.id}
            onClick={() => setActiveGame(g.id)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-all duration-200 ${
              activeGame === g.id
                ? 'bg-primary text-white border-primary shadow-lg shadow-primary/20'
                : 'bg-white/5 text-muted-foreground border-white/10 hover:text-white hover:border-white/20'
            }`}
          >
            <span>{g.emoji}</span> {g.label}
          </button>
        ))}
      </div>

      <div className="flex justify-center">
        {activeGame === 'car' && <CarRaceGame onCoinEarned={handleCoinEarned} />}
        {activeGame === 'snake' && <SnakeGame onCoinEarned={handleCoinEarned} />}
        {activeGame === 'ninja' && <NinjaFlyerGame onCoinEarned={handleCoinEarned} />}
      </div>
    </div>
  );
}
