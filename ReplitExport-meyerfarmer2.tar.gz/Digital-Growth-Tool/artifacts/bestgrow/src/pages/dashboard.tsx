import { useState } from 'react';
import { Link } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import {
  TrendingUp, Package, Users, Star, Copy, Plus,
  LogOut, BarChart3, ShoppingBag, ArrowRight, Wallet,
  Home, Gamepad2, Settings, Lock, ChevronRight, Menu, X,
  GraduationCap, Play
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { GamesSection } from '@/components/games-section';
import { LessonOverlay, LessonType } from '@/components/lesson-overlay';

interface DashboardProps {
  user: { name: string; email: string };
  onLogout: () => void;
}

type Tab = 'overview' | 'orders' | 'games' | 'academy' | 'referral' | 'settings';

const SIDEBAR_ITEMS: { id: Tab; label: string; icon: React.ElementType; emoji: string }[] = [
  { id: 'overview', label: 'Home', icon: Home, emoji: '🏠' },
  { id: 'orders', label: 'Orders', icon: Package, emoji: '📦' },
  { id: 'games', label: 'Games', icon: Gamepad2, emoji: '🎮' },
  { id: 'academy', label: 'Academy', icon: GraduationCap, emoji: '🎓' },
  { id: 'referral', label: 'Referral', icon: Users, emoji: '👥' },
  { id: 'settings', label: 'Settings', icon: Settings, emoji: '⚙️' },
];

const stats = [
  { label: 'Total Orders', value: '0', icon: Package, color: 'from-purple-500 to-blue-500' },
  { label: 'Followers Gained', value: '0', icon: Users, color: 'from-pink-500 to-rose-500' },
  { label: 'Total Spent', value: '₦0', icon: TrendingUp, color: 'from-cyan-500 to-teal-500' },
  { label: 'Referral Bonus', value: '₦0', icon: Star, color: 'from-amber-500 to-orange-500' },
];

const container = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.07 } } };
const item = { hidden: { opacity: 0, y: 16 }, show: { opacity: 1, y: 0 } };

export default function DashboardPage({ user, onLogout }: DashboardProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeLesson, setActiveLesson] = useState<LessonType>(null);

  const copyRef = () => {
    navigator.clipboard.writeText('REF12345');
    toast({ title: 'Copied!', description: 'Referral code copied to clipboard.' });
  };

  const initial = user.name ? user.name.charAt(0).toUpperCase() : '?';

  return (
    <div className="min-h-screen pt-16 relative z-10 flex">

      {/* Mobile sidebar backdrop */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* SIDEBAR */}
      <aside className={`fixed top-16 left-0 h-[calc(100vh-4rem)] w-60 bg-black/40 border-r border-white/5 z-40 flex flex-col backdrop-blur-xl transition-transform duration-300 lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary to-secondary flex items-center justify-center text-white font-bold shadow-lg shadow-primary/30 shrink-0">
              {initial}
            </div>
            <div className="min-w-0">
              <p className="text-white font-semibold text-sm truncate">{user.name.split(' ')[0]}</p>
              <p className="text-muted-foreground text-xs truncate">{user.email}</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {SIDEBAR_ITEMS.map((nav) => (
            <button
              key={nav.id}
              onClick={() => { setActiveTab(nav.id); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 text-left ${
                activeTab === nav.id
                  ? 'bg-primary text-white shadow-lg shadow-primary/20'
                  : 'text-muted-foreground hover:text-white hover:bg-white/5'
              }`}
            >
              <nav.icon className="w-4 h-4 shrink-0" />
              {nav.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/10 space-y-2">
          <Link href="/order">
            <Button variant="gradient" className="w-full gap-2 text-sm">
              <Plus className="w-4 h-4" /> New Order
            </Button>
          </Link>
          <Button variant="ghost" onClick={onLogout} className="w-full gap-2 text-muted-foreground hover:text-red-400 text-sm">
            <LogOut className="w-4 h-4" /> Logout
          </Button>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <div className="flex-1 lg:ml-60 min-w-0">
        <div className="flex items-center gap-3 px-4 py-3 border-b border-white/5 bg-black/20 lg:hidden sticky top-16 z-20 backdrop-blur-lg">
          <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-xl bg-white/5 border border-white/10 text-muted-foreground hover:text-white transition-colors">
            <Menu className="w-5 h-5" />
          </button>
          <h2 className="text-white font-semibold">
            {SIDEBAR_ITEMS.find(i => i.id === activeTab)?.emoji} {SIDEBAR_ITEMS.find(i => i.id === activeTab)?.label}
          </h2>
        </div>

        <div className="p-4 sm:p-6 lg:p-8">
          <AnimatePresence mode="wait">

            {/* ── OVERVIEW ── */}
            {activeTab === 'overview' && (
              <motion.div key="overview" variants={container} initial="hidden" animate="show" exit={{ opacity: 0 }} className="space-y-6">
                <motion.div variants={item} className="flex items-center justify-between flex-wrap gap-4">
                  <div>
                    <h1 className="text-2xl font-display font-bold text-white">Welcome, {user.name.split(' ')[0]}! 👋</h1>
                    <p className="text-muted-foreground text-sm mt-0.5">Here's your growth dashboard</p>
                  </div>
                  <Link href="/wallet">
                    <Button variant="glass" size="sm" className="gap-2">
                      <Wallet className="w-4 h-4" /> Wallet
                    </Button>
                  </Link>
                </motion.div>

                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  {stats.map((s) => (
                    <motion.div key={s.label} variants={item}>
                      <Card className="border-white/10 bg-white/5 hover:bg-white/8 transition-colors">
                        <CardContent className="p-5">
                          <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center mb-4 shadow-lg`}>
                            <s.icon className="w-5 h-5 text-white" />
                          </div>
                          <p className="text-muted-foreground text-xs mb-1">{s.label}</p>
                          <p className="text-2xl font-display font-bold text-white">{s.value}</p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>

                <motion.div variants={item} className="grid sm:grid-cols-3 gap-4">
                  <Link href="/order">
                    <div className="group p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-primary/30 hover:bg-white/8 transition-all cursor-pointer space-y-3 h-full">
                      <div className="text-3xl">🚀</div>
                      <div>
                        <h3 className="font-bold text-white">Boost Your Growth</h3>
                        <p className="text-muted-foreground text-sm mt-1">Get followers, likes and engagement instantly.</p>
                      </div>
                      <Button variant="gradient" size="sm" className="gap-2">Start Now <ArrowRight className="w-3 h-3" /></Button>
                    </div>
                  </Link>

                  <div className="group p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-secondary/30 hover:bg-white/8 transition-all cursor-pointer space-y-3"
                    onClick={() => setActiveTab('academy')}>
                    <div className="text-3xl">🎓</div>
                    <div>
                      <h3 className="font-bold text-white">Learn Growth</h3>
                      <p className="text-muted-foreground text-sm mt-1">Free & premium strategies to grow organically.</p>
                    </div>
                    <Button variant="outline" size="sm" className="gap-1 border-secondary/30 text-secondary hover:bg-secondary/10">
                      Open Academy <ArrowRight className="w-3 h-3" />
                    </Button>
                  </div>

                  <div className="group p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-accent/30 hover:bg-white/8 transition-all cursor-pointer space-y-3"
                    onClick={() => setActiveTab('games')}>
                    <div className="text-3xl">🎮</div>
                    <div>
                      <h3 className="font-bold text-white">Play & Earn</h3>
                      <p className="text-muted-foreground text-sm mt-1">3 games · Earn coins by beating your high score.</p>
                    </div>
                    <Button variant="outline" size="sm" className="gap-1 border-accent/30 text-accent hover:bg-accent/10">
                      Play Now <ArrowRight className="w-3 h-3" />
                    </Button>
                  </div>
                </motion.div>

                <motion.div variants={item}>
                  <Card className="border-white/10 bg-white/5">
                    <CardHeader className="pb-4">
                      <CardTitle className="text-lg font-display flex items-center justify-between">
                        Recent Orders
                        <button onClick={() => setActiveTab('orders')} className="text-sm text-primary font-medium hover:underline flex items-center gap-1">
                          View all <ChevronRight className="w-4 h-4" />
                        </button>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-col items-center justify-center py-10 text-center gap-4">
                        <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                          <ShoppingBag className="w-8 h-8 text-muted-foreground" />
                        </div>
                        <div>
                          <p className="text-white font-semibold mb-1">No orders yet</p>
                          <p className="text-muted-foreground text-sm">Your orders will appear here once you make your first purchase.</p>
                        </div>
                        <Link href="/order">
                          <Button variant="gradient" className="gap-2 mt-2">
                            Place Your First Order <ArrowRight className="w-4 h-4" />
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div variants={item}>
                  <Link href="/wallet">
                    <div className="flex items-center justify-between p-5 rounded-2xl bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/20 hover:border-primary/40 transition-all cursor-pointer group">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                          <Wallet className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                          <p className="text-white font-semibold">My Wallet</p>
                          <p className="text-muted-foreground text-sm">Balance: <span className="text-white font-bold">₦0</span></p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-primary font-medium hidden sm:block group-hover:underline">Deposit Funds</span>
                        <ArrowRight className="w-4 h-4 text-primary" />
                      </div>
                    </div>
                  </Link>
                </motion.div>

                <motion.div variants={item}>
                  <Card className="border-white/10 bg-white/5">
                    <CardHeader>
                      <CardTitle className="text-lg font-display flex items-center gap-2">
                        <BarChart3 className="w-5 h-5 text-primary" /> Growth Analytics
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-40 flex flex-col items-center justify-center gap-3 text-center">
                        <BarChart3 className="w-10 h-10 text-white/10" />
                        <p className="text-muted-foreground text-sm">Analytics will appear after your first order is delivered.</p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </motion.div>
            )}

            {/* ── ORDERS ── */}
            {activeTab === 'orders' && (
              <motion.div key="orders" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-display font-bold text-white">📦 All Orders</h2>
                  <Link href="/order">
                    <Button variant="gradient" size="sm" className="gap-2">
                      <Plus className="w-4 h-4" /> New Order
                    </Button>
                  </Link>
                </div>
                <Card className="border-white/10 bg-white/5">
                  <CardContent>
                    <div className="flex flex-col items-center justify-center py-16 text-center gap-4">
                      <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                        <Package className="w-8 h-8 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-white font-semibold mb-1">No orders yet</p>
                        <p className="text-muted-foreground text-sm">Once you place an order, it will show up here with its status and details.</p>
                      </div>
                      <Link href="/order">
                        <Button variant="gradient" className="gap-2 mt-2">
                          Place Your First Order <ArrowRight className="w-4 h-4" />
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* ── GAMES ── */}
            {activeTab === 'games' && (
              <motion.div key="games" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <GamesSection />
              </motion.div>
            )}

            {/* ── ACADEMY ── */}
            {activeTab === 'academy' && (
              <motion.div key="academy" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-6">
                <div>
                  <h2 className="text-xl font-display font-bold text-white flex items-center gap-2">
                    <GraduationCap className="w-6 h-6 text-secondary" /> Growth Academy
                  </h2>
                  <p className="text-muted-foreground text-sm mt-1">Learn the secrets to organic virality.</p>
                </div>

                <div className="grid sm:grid-cols-3 gap-5">
                  {/* Instagram — FREE */}
                  <div className="rounded-2xl overflow-hidden border border-white/10 flex flex-col">
                    <div className="h-40 bg-gradient-to-br from-pink-600 to-orange-500 p-5 flex flex-col justify-end relative overflow-hidden">
                      <div className="absolute -right-3 -bottom-3 text-7xl opacity-20">📸</div>
                      <h3 className="text-xl font-bold text-white relative z-10">Instagram</h3>
                      <p className="text-white/80 text-sm relative z-10">Algorithm Secrets</p>
                    </div>
                    <div className="bg-card p-4 flex-1 flex flex-col gap-3">
                      <p className="text-muted-foreground text-sm flex-1">Learn how to hack the Instagram algorithm and grow organically with Reels and hashtags.</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-medium text-green-400 bg-green-400/10 px-2 py-1 rounded-full border border-green-400/20">Free Course</span>
                        <Button size="sm" variant="gradient" className="gap-1 h-8" onClick={() => setActiveLesson('insta')}>
                          <Play className="w-3 h-3" /> Open
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* TikTok — FREE */}
                  <div className="rounded-2xl overflow-hidden border border-white/10 flex flex-col">
                    <div className="h-40 bg-gradient-to-br from-cyan-500 to-blue-600 p-5 flex flex-col justify-end relative overflow-hidden">
                      <div className="absolute -right-3 -bottom-3 text-7xl opacity-20">🎵</div>
                      <h3 className="text-xl font-bold text-white relative z-10">TikTok</h3>
                      <p className="text-white/80 text-sm relative z-10">Viral Strategies</p>
                    </div>
                    <div className="bg-card p-4 flex-1 flex flex-col gap-3">
                      <p className="text-muted-foreground text-sm flex-1">Master TikTok's FYP algorithm and build a viral content strategy from day one.</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-medium text-green-400 bg-green-400/10 px-2 py-1 rounded-full border border-green-400/20">Free Course</span>
                        <Button size="sm" variant="gradient" className="gap-1 h-8" onClick={() => setActiveLesson('tiktok')}>
                          <Play className="w-3 h-3" /> Open
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Premium — LOCKED */}
                  <div className="rounded-2xl overflow-hidden border border-accent/30 flex flex-col bg-gradient-to-b from-purple-950/50 to-card">
                    <div className="h-40 bg-gradient-to-br from-purple-800 to-black p-5 flex flex-col justify-end relative overflow-hidden">
                      <div className="absolute -right-3 -bottom-3 text-7xl opacity-20">💎</div>
                      <h3 className="text-xl font-bold text-white flex items-center gap-2 relative z-10">
                        Premium <span className="text-xs bg-accent/20 text-accent px-2 py-0.5 rounded border border-accent/30">Locked</span>
                      </h3>
                      <p className="text-white/60 text-sm relative z-10">Elite Monetization</p>
                    </div>
                    <div className="p-4 flex-1 flex flex-col gap-3">
                      <p className="text-muted-foreground text-sm flex-1">Turn 1,000 followers into ₦500k/month. Includes DM funnel, product system & conversion scripts.</p>
                      <div className="flex items-center justify-between">
                        <span className="text-accent font-bold text-sm">₦4,000</span>
                        <Button size="sm" variant="gradient" className="gap-1 h-8" onClick={() => setActiveLesson('premium')}>
                          <Lock className="w-3 h-3" /> Unlock
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ── REFERRAL ── */}
            {activeTab === 'referral' && (
              <motion.div key="referral" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-6 max-w-lg">
                <h2 className="text-xl font-display font-bold text-white">👥 Referral Program</h2>
                <Card className="border-primary/30 bg-gradient-to-br from-primary/10 to-secondary/10">
                  <CardContent className="p-8 text-center space-y-6">
                    <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center mx-auto">
                      <Star className="w-8 h-8 text-primary" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-display font-bold text-white mb-2">Earn Free Growth 🎁</h2>
                      <p className="text-muted-foreground text-sm">Share your code. Every friend who orders gives you 3% commission.</p>
                    </div>
                    <div className="bg-black/40 rounded-xl p-4 flex items-center justify-between border border-white/10">
                      <span className="font-mono text-xl font-bold tracking-widest text-white">REF12345</span>
                      <Button size="sm" variant="gradient" onClick={copyRef} className="gap-2">
                        <Copy className="w-4 h-4" /> Copy
                      </Button>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-center pt-2">
                      {[{ label: 'Friends Referred', val: '0' }, { label: 'Bonus Earned', val: '₦0' }, { label: 'Pending Bonus', val: '₦0' }].map(s => (
                        <div key={s.label} className="bg-black/20 rounded-xl p-3">
                          <p className="text-xl font-bold text-white">{s.val}</p>
                          <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* ── SETTINGS ── */}
            {activeTab === 'settings' && (
              <motion.div key="settings" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-6 max-w-lg">
                <h2 className="text-xl font-display font-bold text-white">⚙️ Settings</h2>

                <Card className="border-white/10 bg-white/5">
                  <CardContent className="p-6 space-y-4">
                    <h3 className="font-semibold text-white">Account</h3>
                    <div className="flex items-center justify-between py-3 border-b border-white/5">
                      <div>
                        <p className="text-white font-medium text-sm">Name</p>
                        <p className="text-muted-foreground text-xs">{user.name}</p>
                      </div>
                      <Button variant="ghost" size="sm" className="text-primary text-xs">Edit</Button>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-white/5">
                      <div>
                        <p className="text-white font-medium text-sm">Email</p>
                        <p className="text-muted-foreground text-xs">{user.email}</p>
                      </div>
                      <Button variant="ghost" size="sm" className="text-primary text-xs">Edit</Button>
                    </div>
                    <div className="flex items-center justify-between py-3">
                      <div>
                        <p className="text-white font-medium text-sm">Password</p>
                        <p className="text-muted-foreground text-xs">Last changed never</p>
                      </div>
                      <Button variant="ghost" size="sm" className="text-primary text-xs">Change</Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-white/10 bg-white/5">
                  <CardContent className="p-6 space-y-4">
                    <h3 className="font-semibold text-white">Notifications</h3>
                    {['Order updates', 'Referral bonuses', 'Promotions & offers'].map((label) => (
                      <div key={label} className="flex items-center justify-between py-2">
                        <p className="text-muted-foreground text-sm">{label}</p>
                        <div className="w-10 h-5 bg-primary/30 border border-primary/50 rounded-full flex items-center px-0.5">
                          <div className="w-4 h-4 rounded-full bg-primary ml-auto shadow" />
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="border-red-500/20 bg-red-500/5">
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-red-400 mb-3">Danger Zone</h3>
                    <Button variant="outline" className="border-red-500/30 text-red-400 hover:bg-red-500/10 gap-2" onClick={onLogout}>
                      <LogOut className="w-4 h-4" /> Sign Out
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </div>

      {/* Lesson overlay accessible from Academy tab */}
      <LessonOverlay type={activeLesson} onClose={() => setActiveLesson(null)} />
    </div>
  );
}
