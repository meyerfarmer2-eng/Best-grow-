import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Wallet, Plus, Copy, Building2, ArrowDownLeft,
  Clock, CheckCircle2, AlertCircle, X, ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

interface WalletProps {
  user: { name: string; email: string };
}

interface Deposit {
  id: string;
  amount: number;
  ref: string;
  date: string;
  status: 'pending' | 'confirmed';
}

function getWalletData() {
  const raw = localStorage.getItem('bestgrow_wallet');
  if (raw) return JSON.parse(raw) as { balance: number; deposits: Deposit[] };
  return { balance: 0, deposits: [] };
}

function saveWalletData(data: { balance: number; deposits: Deposit[] }) {
  localStorage.setItem('bestgrow_wallet', JSON.stringify(data));
}

const container = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.07 } } };
const item = { hidden: { opacity: 0, y: 16 }, show: { opacity: 1, y: 0 } };

export default function WalletPage({ user }: WalletProps) {
  const { toast } = useToast();
  const [walletData, setWalletData] = useState(getWalletData);
  const [showDeposit, setShowDeposit] = useState(false);
  const [amount, setAmount] = useState('');
  const [senderRef, setSenderRef] = useState('');
  const [step, setStep] = useState<'form' | 'transfer' | 'submitted'>('form');
  const [submitting, setSubmitting] = useState(false);

  const copyAccount = () => {
    navigator.clipboard.writeText('9036377376');
    toast({ title: 'Copied!', description: 'Account number copied.' });
  };

  const handleAmountNext = () => {
    const val = parseInt(amount);
    if (!val || val < 100) {
      toast({ title: 'Minimum deposit is ₦100', variant: 'destructive' });
      return;
    }
    setStep('transfer');
  };

  const handleSubmitProof = () => {
    if (!senderRef.trim()) {
      toast({ title: 'Enter your name or reference', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      const deposit: Deposit = {
        id: `DEP-${Date.now()}`,
        amount: parseInt(amount),
        ref: senderRef,
        date: new Date().toLocaleDateString('en-NG', { day: 'numeric', month: 'short', year: 'numeric' }),
        status: 'pending',
      };
      const updated = {
        balance: walletData.balance,
        deposits: [deposit, ...walletData.deposits],
      };
      saveWalletData(updated);
      setWalletData(updated);
      setSubmitting(false);
      setStep('submitted');
    }, 1000);
  };

  const closeDeposit = () => {
    setShowDeposit(false);
    setTimeout(() => { setStep('form'); setAmount(''); setSenderRef(''); }, 300);
  };

  const pendingCount = walletData.deposits.filter((d) => d.status === 'pending').length;

  return (
    <div className="min-h-screen pt-24 pb-20 px-4 sm:px-6 relative z-10">
      <div className="max-w-3xl mx-auto space-y-8">

        {/* Page title */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-3xl font-display font-bold text-white">My Wallet</h1>
          <p className="text-muted-foreground text-sm mt-1">Deposit funds and pay for orders instantly</p>
        </motion.div>

        <motion.div variants={container} initial="hidden" animate="show" className="space-y-6">

          {/* Balance card */}
          <motion.div variants={item}>
            <div className="relative rounded-3xl overflow-hidden p-8 bg-gradient-to-br from-primary to-secondary shadow-2xl shadow-primary/30">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(255,255,255,0.12)_0%,_transparent_60%)]" />
              <div className="relative space-y-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-white/70 text-sm font-medium uppercase tracking-wider mb-2">Available Balance</p>
                    <p className="text-5xl font-display font-bold text-white">
                      ₦{walletData.balance.toLocaleString()}
                    </p>
                  </div>
                  <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-sm flex items-center justify-center border border-white/20">
                    <Wallet className="w-7 h-7 text-white" />
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <p className="text-white/60 text-sm">{user.email}</p>
                  {pendingCount > 0 && (
                    <span className="bg-yellow-400/20 border border-yellow-400/40 text-yellow-300 text-xs px-2.5 py-1 rounded-full font-medium">
                      {pendingCount} pending
                    </span>
                  )}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Quick actions */}
          <motion.div variants={item} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button
              onClick={() => setShowDeposit(true)}
              className="flex items-center gap-4 p-5 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/8 hover:border-primary/30 transition-all group text-left"
            >
              <div className="w-12 h-12 rounded-xl bg-primary/15 group-hover:bg-primary/25 flex items-center justify-center transition-colors">
                <Plus className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-semibold text-white">Deposit Funds</p>
                <p className="text-muted-foreground text-xs mt-0.5">Add money via bank transfer</p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto group-hover:text-white transition-colors" />
            </button>

            <div className="flex items-center gap-4 p-5 rounded-2xl bg-white/5 border border-white/10 text-left opacity-60">
              <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center">
                <ArrowDownLeft className="w-6 h-6 text-muted-foreground" />
              </div>
              <div>
                <p className="font-semibold text-white">Withdraw</p>
                <p className="text-muted-foreground text-xs mt-0.5">Coming soon</p>
              </div>
            </div>
          </motion.div>

          {/* Deposit history */}
          <motion.div variants={item}>
            <Card className="border-white/10 bg-white/5">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg font-display flex items-center gap-2">
                  <Clock className="w-5 h-5 text-primary" /> Deposit History
                </CardTitle>
              </CardHeader>
              <CardContent>
                {walletData.deposits.length === 0 ? (
                  <div className="flex flex-col items-center py-12 text-center gap-3">
                    <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                      <Wallet className="w-7 h-7 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-white font-semibold">No deposits yet</p>
                      <p className="text-muted-foreground text-sm mt-1">Your deposit history will appear here.</p>
                    </div>
                    <Button variant="gradient" className="gap-2 mt-2" onClick={() => setShowDeposit(true)}>
                      <Plus className="w-4 h-4" /> Make First Deposit
                    </Button>
                  </div>
                ) : (
                  <div className="divide-y divide-white/5">
                    {walletData.deposits.map((dep) => (
                      <div key={dep.id} className="flex items-center justify-between py-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${dep.status === 'confirmed' ? 'bg-green-400/10' : 'bg-yellow-400/10'}`}>
                            {dep.status === 'confirmed'
                              ? <CheckCircle2 className="w-5 h-5 text-green-400" />
                              : <Clock className="w-5 h-5 text-yellow-400" />
                            }
                          </div>
                          <div>
                            <p className="text-white font-medium text-sm">Bank Transfer</p>
                            <p className="text-muted-foreground text-xs">{dep.ref} · {dep.date}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-white font-bold">+₦{dep.amount.toLocaleString()}</p>
                          <span className={`text-xs font-medium ${dep.status === 'confirmed' ? 'text-green-400' : 'text-yellow-400'}`}>
                            {dep.status === 'confirmed' ? 'Confirmed' : 'Under Review'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

        </motion.div>
      </div>

      {/* Deposit Modal */}
      <AnimatePresence>
        {showDeposit && (
          <>
            <motion.div
              key="dep-bg"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm"
              onClick={closeDeposit}
            />
            <motion.div
              key="dep-modal"
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: 'spring', stiffness: 300, damping: 28 }}
              className="fixed z-50 inset-x-4 top-1/2 -translate-y-1/2 sm:inset-auto sm:left-1/2 sm:-translate-x-1/2 sm:w-[440px] bg-card border border-white/10 rounded-3xl shadow-2xl overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal header */}
              <div className="flex items-center justify-between px-6 py-5 border-b border-white/10">
                <h3 className="font-display font-bold text-white text-lg">
                  {step === 'form' && 'Deposit Funds'}
                  {step === 'transfer' && 'Make Transfer'}
                  {step === 'submitted' && 'Submitted!'}
                </h3>
                <button onClick={closeDeposit} className="w-8 h-8 flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors text-muted-foreground hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-6 space-y-5">
                {/* Step 1: amount */}
                {step === 'form' && (
                  <>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-muted-foreground">Amount to Deposit (₦)</label>
                      <div className="relative">
                        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground font-bold">₦</span>
                        <Input
                          type="number"
                          placeholder="e.g. 5000"
                          className="pl-8 h-12 text-lg font-bold"
                          value={amount}
                          onChange={(e) => setAmount(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      {[500, 1000, 2000, 5000].map((q) => (
                        <button
                          key={q}
                          onClick={() => setAmount(String(q))}
                          className={`px-4 py-2 rounded-xl text-sm font-medium border transition-all ${
                            amount === String(q)
                              ? 'bg-primary/15 border-primary/50 text-white'
                              : 'bg-white/5 border-white/10 text-muted-foreground hover:text-white hover:border-white/20'
                          }`}
                        >
                          ₦{q.toLocaleString()}
                        </button>
                      ))}
                    </div>
                    <Button variant="gradient" className="w-full h-12 font-bold" onClick={handleAmountNext}>
                      Continue
                    </Button>
                  </>
                )}

                {/* Step 2: bank transfer details */}
                {step === 'transfer' && (
                  <>
                    <div className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Building2 className="w-4 h-4 text-primary" />
                        <span className="font-semibold text-white text-sm">Transfer ₦{parseInt(amount).toLocaleString()} to:</span>
                      </div>
                      {[
                        { label: 'Bank', value: 'Opay' },
                        { label: 'Account Name', value: 'Davidbest Johnson Ebong' },
                      ].map((r) => (
                        <div key={r.label} className="flex justify-between text-sm">
                          <span className="text-muted-foreground">{r.label}</span>
                          <span className="text-white font-medium">{r.value}</span>
                        </div>
                      ))}
                      <div className="flex justify-between items-center border-t border-white/10 pt-3">
                        <span className="text-muted-foreground text-sm">Account No.</span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-lg font-bold text-primary tracking-wider">9036377376</span>
                          <button onClick={copyAccount} className="p-1.5 hover:bg-white/10 rounded-lg transition-colors">
                            <Copy className="w-3.5 h-3.5 text-muted-foreground hover:text-white" />
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-muted-foreground">Your Name / Transfer Reference</label>
                      <Input
                        placeholder="e.g. John Doe"
                        value={senderRef}
                        onChange={(e) => setSenderRef(e.target.value)}
                      />
                    </div>

                    <div className="flex gap-3">
                      <Button variant="outline" className="flex-1" onClick={() => setStep('form')}>Back</Button>
                      <Button variant="gradient" className="flex-1 font-bold" onClick={handleSubmitProof} disabled={submitting}>
                        {submitting ? (
                          <span className="flex items-center gap-2">
                            <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            Submitting...
                          </span>
                        ) : "I've Paid"}
                      </Button>
                    </div>
                  </>
                )}

                {/* Step 3: submitted */}
                {step === 'submitted' && (
                  <div className="flex flex-col items-center text-center py-4 space-y-5">
                    <div className="w-20 h-20 rounded-full bg-yellow-400/10 border border-yellow-400/30 flex items-center justify-center">
                      <AlertCircle className="w-10 h-10 text-yellow-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white mb-2">Deposit Under Review</h3>
                      <p className="text-muted-foreground text-sm">
                        Your ₦{parseInt(amount).toLocaleString()} deposit has been submitted. Once we confirm your transfer, it'll be credited to your wallet (usually within minutes).
                      </p>
                    </div>
                    <Button variant="gradient" className="w-full" onClick={closeDeposit}>Done</Button>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
