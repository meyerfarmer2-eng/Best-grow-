import { useState } from 'react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { Zap, TrendingUp, Check, Play, Gamepad2, GraduationCap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { LessonOverlay, LessonType } from '@/components/lesson-overlay';
import { GameOverlay } from '@/components/game-overlay';

export default function HomePage() {
  const [activeLesson, setActiveLesson] = useState<LessonType>(null);
  const [gameOpen, setGameOpen] = useState(false);

  const containerVars = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVars = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
  };

  return (
    <>
      <main className="relative z-10 pt-20 pb-20">
        
        {/* HERO SECTION */}
        <section className="relative min-h-[80vh] flex flex-col items-center justify-center px-4 overflow-hidden">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-center max-w-4xl mx-auto space-y-8"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-sm font-medium text-primary mb-4 backdrop-blur-sm">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              #1 Social Growth Platform
            </div>
            
            <h1 className="text-5xl sm:text-7xl font-display font-black tracking-tight text-white leading-tight">
              Grow Your Social Media <br className="hidden sm:block" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-secondary text-glow">Fast ⚡</span>
            </h1>
            
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto font-medium">
              Real Followers • Instant Likes • Viral Views • True Engagement
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <Link href="/auth">
                <Button size="lg" variant="gradient" className="w-full sm:w-auto h-14 px-8 text-lg font-bold group">
                  <Zap className="mr-2 w-5 h-5 group-hover:scale-110 transition-transform" />
                  Get Started Now
                </Button>
              </Link>
              <Button 
                size="lg" 
                variant="glass" 
                className="w-full sm:w-auto h-14 px-8 text-lg"
                onClick={() => setGameOpen(true)}
              >
                <Gamepad2 className="mr-2 w-5 h-5" />
                Play Minigame
              </Button>
            </div>
          </motion.div>
        </section>

        {/* PRICING SECTION */}
        <section id="pricing" className="py-24 px-4 sm:px-6 max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mb-4">Transparent Pricing 💰</h2>
            <p className="text-muted-foreground">Start small or go viral. Choose your tier.</p>
          </div>

          <motion.div 
            variants={containerVars}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-100px" }}
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto"
          >
            {[
              { name: "Starter", amount: "100", price: "2000", popular: false },
              { name: "Pro", amount: "500", price: "8000", popular: true },
              { name: "Elite", amount: "1000", price: "14000", popular: false },
            ].map((plan, i) => (
              <motion.div key={plan.name} variants={itemVars}>
                <Card className={`relative h-full flex flex-col ${plan.popular ? 'border-primary shadow-[0_0_30px_rgba(168,85,247,0.2)]' : 'border-white/10'}`}>
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-3 py-1 bg-primary text-white text-xs font-bold rounded-full tracking-wider uppercase">
                      MOST POPULAR
                    </div>
                  )}
                  <CardHeader>
                    <CardTitle className="text-xl text-muted-foreground">{plan.name}</CardTitle>
                    <div className="mt-4 flex items-baseline text-4xl font-black text-white">
                      <span className="text-2xl text-muted-foreground mr-1">₦</span>
                      {plan.price}
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-3">
                      <li className="flex items-center text-sm font-medium">
                        <Check className="w-5 h-5 text-primary mr-3 shrink-0" />
                        {plan.amount} High-Quality Followers
                      </li>
                      <li className="flex items-center text-sm text-muted-foreground">
                        <Check className="w-5 h-5 text-primary/50 mr-3 shrink-0" />
                        Instant Delivery
                      </li>
                      <li className="flex items-center text-sm text-muted-foreground">
                        <Check className="w-5 h-5 text-primary/50 mr-3 shrink-0" />
                        24/7 Support
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Link href="/auth" className="w-full">
                      <Button variant={plan.popular ? "default" : "outline"} className="w-full">Choose {plan.name}</Button>
                    </Link>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </section>

        {/* ACADEMY SECTION */}
        <section className="py-24 px-4 sm:px-6 max-w-7xl mx-auto relative">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent pointer-events-none" />
          
          <div className="text-center mb-16 relative">
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mb-4 flex items-center justify-center gap-3">
              <GraduationCap className="w-8 h-8 text-secondary" /> Growth Academy
            </h2>
            <p className="text-muted-foreground">Learn the secrets to organic virality.</p>
          </div>

          <div className="grid sm:grid-cols-3 gap-6 max-w-5xl mx-auto relative">
            {/* Insta */}
            <motion.div whileHover={{ y: -5 }} className="group cursor-pointer" onClick={() => setActiveLesson('insta')}>
              <div className="h-48 rounded-t-2xl bg-gradient-to-br from-pink-600 to-orange-500 p-6 flex flex-col justify-end relative overflow-hidden">
                <div className="absolute -right-4 -bottom-4 text-8xl opacity-20 group-hover:scale-110 transition-transform">📸</div>
                <h3 className="text-2xl font-bold text-white relative z-10">Instagram</h3>
                <p className="text-white/80 text-sm relative z-10">Algorithm Secrets</p>
              </div>
              <div className="bg-card border border-t-0 border-white/10 rounded-b-2xl p-4 flex justify-between items-center group-hover:bg-white/5 transition-colors">
                <span className="text-sm font-medium text-muted-foreground">Free Course</span>
                <Button size="sm" variant="ghost" className="rounded-full w-8 h-8 p-0 group-hover:bg-white/10 group-hover:text-white">
                  <Play className="w-4 h-4 ml-0.5" />
                </Button>
              </div>
            </motion.div>

            {/* TikTok */}
            <motion.div whileHover={{ y: -5 }} className="group cursor-pointer" onClick={() => setActiveLesson('tiktok')}>
              <div className="h-48 rounded-t-2xl bg-gradient-to-br from-cyan-500 to-blue-600 p-6 flex flex-col justify-end relative overflow-hidden">
                <div className="absolute -right-4 -bottom-4 text-8xl opacity-20 group-hover:scale-110 transition-transform">🎵</div>
                <h3 className="text-2xl font-bold text-white relative z-10">TikTok</h3>
                <p className="text-white/80 text-sm relative z-10">Viral Strategies</p>
              </div>
              <div className="bg-card border border-t-0 border-white/10 rounded-b-2xl p-4 flex justify-between items-center group-hover:bg-white/5 transition-colors">
                <span className="text-sm font-medium text-muted-foreground">Free Course</span>
                <Button size="sm" variant="ghost" className="rounded-full w-8 h-8 p-0 group-hover:bg-white/10 group-hover:text-white">
                  <Play className="w-4 h-4 ml-0.5" />
                </Button>
              </div>
            </motion.div>

            {/* Premium */}
            <motion.div whileHover={{ y: -5 }} className="group cursor-pointer" onClick={() => setActiveLesson('premium')}>
              <div className="h-48 rounded-t-2xl bg-gradient-to-br from-purple-800 to-black border border-b-0 border-white/10 p-6 flex flex-col justify-end relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMSIgY3k9IjEiIHI9IjEiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4xKSIvPjwvc3ZnPg==')] opacity-50"></div>
                <div className="absolute -right-4 -bottom-4 text-8xl opacity-20 group-hover:scale-110 transition-transform">💎</div>
                <h3 className="text-2xl font-bold text-white flex items-center gap-2 relative z-10">
                  Premium <span className="text-xs bg-accent/20 text-accent px-2 py-1 rounded-md border border-accent/30">Locked</span>
                </h3>
                <p className="text-white/60 text-sm relative z-10">Elite Monetization</p>
              </div>
              <div className="bg-card border border-t-0 border-white/10 rounded-b-2xl p-4 flex justify-between items-center group-hover:bg-white/5 transition-colors">
                <span className="text-sm font-medium text-accent">₦4000 to Unlock</span>
                <Button size="sm" variant="gradient" className="rounded-full h-8 px-4 text-xs">
                  Unlock
                </Button>
              </div>
            </motion.div>

          </div>
        </section>

      </main>

      {/* Overlays controlled by state */}
      <LessonOverlay type={activeLesson} onClose={() => setActiveLesson(null)} />
      <GameOverlay isOpen={gameOpen} onClose={() => setGameOpen(false)} />
    </>
  );
}
