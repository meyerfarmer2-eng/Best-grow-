import { useState } from 'react';
import { Link } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, CreditCard, Building2, Copy, Lock, Calendar, User, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import confetti from 'canvas-confetti';

interface OrderPageProps {
  user?: { name: string; email: string };
}

const PLATFORMS = [
  { id: 'Instagram', icon: '📸', color: 'from-pink-500 to-orange-400', services: ['Followers', 'Likes', 'Views', 'Comments', 'Story Views', 'Reel Views'] },
  { id: 'TikTok', icon: '🎵', color: 'from-cyan-400 to-blue-600', services: ['Followers', 'Likes', 'Views', 'Comments', 'Shares'] },
  { id: 'YouTube', icon: '▶️', color: 'from-red-500 to-red-700', services: ['Subscribers', 'Views', 'Likes', 'Comments', 'Watch Hours'] },
  { id: 'Facebook', icon: '📘', color: 'from-blue-500 to-blue-700', services: ['Page Likes', 'Followers', 'Post Likes', 'Views', 'Comments'] },
  { id: 'Twitter', icon: '🐦', color: 'from-sky-400 to-sky-600', services: ['Followers', 'Likes', 'Retweets', 'Views', 'Comments'] },
  { id: 'Telegram', icon: '✈️', color: 'from-cyan-500 to-teal-500', services: ['Channel Members', 'Group Members', 'Post Views', 'Reactions'] },
  { id: 'Spotify', icon: '🎧', color: 'from-green-500 to-emerald-600', services: ['Streams', 'Followers', 'Monthly Listeners', 'Playlist Saves'] },
  { id: 'Twitch', icon: '🎮', color: 'from-purple-500 to-violet-600', services: ['Followers', 'Views', 'Clip Views', 'Live Views'] },
  { id: 'LinkedIn', icon: '💼', color: 'from-blue-600 to-blue-800', services: ['Followers', 'Post Likes', 'Comments', 'Connections'] },
  { id: 'Snapchat', icon: '👻', color: 'from-yellow-400 to-yellow-500', services: ['Followers', 'Story Views'] },
  { id: 'Pinterest', icon: '📌', color: 'from-red-400 to-rose-600', services: ['Followers', 'Pin Saves', 'Views'] },
  { id: 'SoundCloud', icon: '🎶', color: 'from-orange-500 to-orange-700', services: ['Plays', 'Followers', 'Likes', 'Reposts'] },
];

const PRICE_PER_UNIT = 8;

function formatCardNumber(val: string) {
  return val.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim();
}
function formatExpiry(val: string) {
  const digits = val.replace(/\D/g, '').slice(0, 4);
  if (digits.length >= 3) return digits.slice(0, 2) + '/' + digits.slice(2);
  return digits;
}

export default function OrderPage({ user }: OrderPageProps) {
  const { toast } = useToast();

  const [platform, setPlatform] = useState(PLATFORMS[0]);
  const [service, setService] = useState(PLATFORMS[0].services[0]);
  const [link, setLink] = useState('');
  const [qty, setQty] = useState<number | ''>('');
  const [coupon, setCoupon] = useState('');
  const [payMethod, setPayMethod] = useState<'card' | 'bank' | 'korapay'>('korapay');
  const [isPaying, setIsPaying] = useState(false);

  // Card fields
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');

  // Bank proof
  const [proof, setProof] = useState('');

  const originalPrice = (Number(qty) || 0) * PRICE_PER_UNIT;
  const discount = coupon.toUpperCase() === 'SAVE10' ? originalPrice * 0.1 : 0;
  const totalPrice = Math.max(0, originalPrice - discount);

  const handlePlatformSelect = (p: typeof PLATFORMS[0]) => {
    setPlatform(p);
    setService(p.services[0]);
  };

  const handleCardPay = () => {
    if (!link || !qty) { toast({ title: 'Missing info', description: 'Please fill in link and quantity.', variant: 'destructive' }); return; }
    if (!cardNumber || !cardName || !expiry || !cvv) { toast({ title: 'Card details required', description: 'Please fill in all card fields.', variant: 'destructive' }); return; }
    setIsPaying(true);
    setTimeout(() => {
      setIsPaying(false);
      confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
      toast({ title: 'Payment Successful! 🎉', description: `Your order of ${qty} ${service} for ${platform.id} is now being processed.` });
      setCardNumber(''); setCardName(''); setExpiry(''); setCvv('');
    }, 1800);
  };

  const handleBankConfirm = () => {
    setIsPaying(true);
    setTimeout(() => {
      setIsPaying(false);
      toast({ title: 'Proof Submitted ✅', description: 'We will verify your payment and start your order within minutes.' });
      setProof('');
    }, 1200);
  };

  const copyAccount = () => {
    navigator.clipboard.writeText('9036377376');
    toast({ title: 'Copied!', description: 'Account number copied.' });
  };

  const copyRef = () => {
    navigator.clipboard.writeText('REF12345');
    toast({ title: 'Copied!', description: 'Referral code copied to clipboard.' });
  };

  const handleKorapay = () => {
    if (!link || !qty) { toast({ title: 'Missing info', description: 'Please fill in link and quantity.', variant: 'destructive' }); return; }
    window.open('https://test-checkout.korapay.com/pay/Paytobestgrow', '_blank');
    confetti({ particleCount: 80, spread: 70, origin: { y: 0.7 } });
    toast({ title: 'Redirecting to Korapay 🔒', description: 'Complete your payment on the Korapay page.' });
  };

  return (
    <div className="min-h-screen pt-24 pb-20 px-4 sm:px-6 relative z-10">
      <div className="max-w-5xl mx-auto space-y-8">

        {/* Back */}
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
          <Link href={user ? '/dashboard' : '/'} className="inline-flex items-center text-muted-foreground hover:text-white transition-colors mb-4 group">
            <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
            {user ? 'Back to Dashboard' : 'Back to Home'}
          </Link>
          <h1 className="text-4xl sm:text-5xl font-display font-bold text-white mb-1">Create Order 📦</h1>
          <p className="text-muted-foreground">Choose your platform and boost your presence instantly.</p>
        </motion.div>

        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          <div className="space-y-8">

            {/* Platform Picker */}
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
              <h2 className="text-lg font-semibold text-white mb-4">Select Platform</h2>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                {PLATFORMS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handlePlatformSelect(p)}
                    className={`flex flex-col items-center gap-2 p-3 rounded-2xl border-2 transition-all duration-200 ${
                      platform.id === p.id
                        ? 'border-primary bg-primary/10 shadow-lg shadow-primary/20'
                        : 'border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/8'
                    }`}
                  >
                    <span className="text-2xl">{p.icon}</span>
                    <span className="text-xs font-medium text-white/80">{p.id}</span>
                  </button>
                ))}
              </div>
            </motion.div>

            {/* Service + Details */}
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="space-y-5">
              <h2 className="text-lg font-semibold text-white">Order Details</h2>

              {/* Service Selector */}
              <div>
                <label className="text-sm font-medium text-muted-foreground mb-2 block">Service Type</label>
                <div className="flex flex-wrap gap-2">
                  {platform.services.map((s) => (
                    <button
                      key={s}
                      onClick={() => setService(s)}
                      className={`px-4 py-2 rounded-xl text-sm font-medium border transition-all duration-200 ${
                        service === s
                          ? 'border-primary bg-primary text-white shadow-md shadow-primary/30'
                          : 'border-white/10 bg-white/5 text-muted-foreground hover:border-white/20 hover:text-white'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Target Link / Username</label>
                <Input
                  placeholder={`https://${platform.id.toLowerCase()}.com/yourprofile`}
                  value={link}
                  onChange={(e) => setLink(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Quantity</label>
                  <Input
                    type="number"
                    min="100"
                    placeholder="e.g. 1000"
                    value={qty}
                    onChange={(e) => setQty(parseInt(e.target.value) || '')}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Promo Code</label>
                  <Input
                    placeholder="Try SAVE10"
                    value={coupon}
                    onChange={(e) => setCoupon(e.target.value)}
                    className={coupon.toUpperCase() === 'SAVE10' ? 'border-green-500/50 text-green-400' : ''}
                  />
                </div>
              </div>
            </motion.div>

            {/* Payment */}
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="space-y-5">
              <h2 className="text-lg font-semibold text-white">Payment Method</h2>

              <div className="grid grid-cols-3 gap-3">
                <button
                  onClick={() => setPayMethod('korapay')}
                  className={`h-16 rounded-2xl border-2 flex flex-col items-center justify-center gap-1 transition-all duration-200 ${
                    payMethod === 'korapay' ? 'border-primary bg-primary/10 text-primary' : 'border-white/10 bg-white/5 text-muted-foreground hover:border-white/20'
                  }`}
                >
                  <Zap className="w-5 h-5" />
                  <span className="text-xs font-semibold">Korapay</span>
                </button>
                <button
                  onClick={() => setPayMethod('card')}
                  className={`h-16 rounded-2xl border-2 flex flex-col items-center justify-center gap-1 transition-all duration-200 ${
                    payMethod === 'card' ? 'border-primary bg-primary/10 text-primary' : 'border-white/10 bg-white/5 text-muted-foreground hover:border-white/20'
                  }`}
                >
                  <CreditCard className="w-5 h-5" />
                  <span className="text-xs font-semibold">Card</span>
                </button>
                <button
                  onClick={() => setPayMethod('bank')}
                  className={`h-16 rounded-2xl border-2 flex flex-col items-center justify-center gap-1 transition-all duration-200 ${
                    payMethod === 'bank' ? 'border-primary bg-primary/10 text-primary' : 'border-white/10 bg-white/5 text-muted-foreground hover:border-white/20'
                  }`}
                >
                  <Building2 className="w-5 h-5" />
                  <span className="text-xs font-semibold">Bank Transfer</span>
                </button>
              </div>

              <AnimatePresence mode="wait">
                {payMethod === 'korapay' ? (
                  <motion.div key="korapay" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-4">
                    <div className="p-5 rounded-2xl bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20 space-y-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                          <Zap className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="text-white font-semibold">Pay with Korapay</p>
                          <p className="text-muted-foreground text-xs">Fast, secure Nigerian payment gateway</p>
                        </div>
                      </div>
                      <ul className="space-y-1.5 text-sm text-muted-foreground">
                        <li className="flex items-center gap-2"><span className="text-primary">✓</span> Card, transfer & USSD supported</li>
                        <li className="flex items-center gap-2"><span className="text-primary">✓</span> Instant payment confirmation</li>
                        <li className="flex items-center gap-2"><span className="text-primary">✓</span> SSL encrypted & secure</li>
                      </ul>
                    </div>
                    <Button
                      onClick={handleKorapay}
                      disabled={!qty || totalPrice === 0}
                      variant="gradient"
                      className="w-full h-14 text-base font-bold"
                    >
                      <Zap className="w-5 h-5 mr-2" />
                      Pay ₦{totalPrice.toLocaleString()} with Korapay
                    </Button>
                    <p className="text-center text-xs text-muted-foreground flex items-center justify-center gap-1">
                      <Lock className="w-3 h-3" /> You will be redirected to Korapay's secure checkout
                    </p>
                  </motion.div>
                ) : payMethod === 'card' ? (
                  <motion.div key="card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-4">
                    {/* Card Visual */}
                    <div className={`relative h-44 rounded-2xl bg-gradient-to-br ${platform.color} p-6 overflow-hidden shadow-xl`}>
                      <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 80% 20%, white 0%, transparent 60%)' }} />
                      <div className="flex justify-between items-start">
                        <div className="w-10 h-7 rounded bg-yellow-400/80" />
                        <span className="text-white/80 text-sm font-bold tracking-widest">BESTGROW</span>
                      </div>
                      <p className="text-white font-mono text-lg tracking-widest mt-4 drop-shadow">
                        {cardNumber || '•••• •••• •••• ••••'}
                      </p>
                      <div className="flex justify-between items-end mt-4">
                        <div>
                          <p className="text-white/60 text-xs uppercase tracking-wider">Card Holder</p>
                          <p className="text-white font-semibold text-sm">{cardName || 'YOUR NAME'}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-white/60 text-xs uppercase tracking-wider">Expires</p>
                          <p className="text-white font-semibold text-sm">{expiry || 'MM/YY'}</p>
                        </div>
                      </div>
                    </div>

                    {/* Card Fields */}
                    <div className="space-y-3">
                      <div className="space-y-1.5">
                        <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                          <CreditCard className="w-4 h-4" /> Card Number
                        </label>
                        <Input
                          placeholder="1234 5678 9012 3456"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                          maxLength={19}
                          className="font-mono tracking-wider"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                          <User className="w-4 h-4" /> Name on Card
                        </label>
                        <Input
                          placeholder="John Doe"
                          value={cardName}
                          onChange={(e) => setCardName(e.target.value.toUpperCase())}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1.5">
                          <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                            <Calendar className="w-4 h-4" /> Expiry Date
                          </label>
                          <Input
                            placeholder="MM/YY"
                            value={expiry}
                            onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                            maxLength={5}
                            className="font-mono"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                            <Lock className="w-4 h-4" /> CVV
                          </label>
                          <Input
                            placeholder="•••"
                            type="password"
                            value={cvv}
                            onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').slice(0, 4))}
                            maxLength={4}
                            className="font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    <Button
                      onClick={handleCardPay}
                      disabled={isPaying || !qty || totalPrice === 0}
                      variant="gradient"
                      className="w-full h-14 text-base font-bold"
                    >
                      {isPaying ? (
                        <span className="flex items-center gap-2">
                          <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          Processing...
                        </span>
                      ) : (
                        <span className="flex items-center gap-2">
                          <Lock className="w-4 h-4" />
                          Pay ₦{totalPrice.toLocaleString()} Securely
                        </span>
                      )}
                    </Button>
                    <p className="text-center text-xs text-muted-foreground flex items-center justify-center gap-1">
                      <Lock className="w-3 h-3" /> 256-bit SSL encrypted · Your card data is secure
                    </p>
                  </motion.div>
                ) : (
                  <motion.div key="bank" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-4">
                    <div className="p-5 rounded-2xl bg-secondary/10 border border-secondary/20 space-y-4">
                      <p className="text-sm text-muted-foreground">Transfer exactly <span className="text-white font-bold">₦{totalPrice.toLocaleString()}</span> to:</p>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground uppercase tracking-wider">Bank</p>
                        <p className="font-bold text-white text-lg">Opay</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground uppercase tracking-wider">Account Name</p>
                        <p className="font-semibold text-white">Davidbest Johnson Ebong</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground uppercase tracking-wider">Account Number</p>
                        <div className="flex items-center gap-3">
                          <p className="font-mono text-2xl font-bold tracking-widest text-primary">9036377376</p>
                          <button onClick={copyAccount} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                            <Copy className="w-4 h-4 text-muted-foreground hover:text-white" />
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <Input
                        placeholder="Your name / payment reference"
                        value={proof}
                        onChange={(e) => setProof(e.target.value)}
                      />
                      <Button onClick={handleBankConfirm} disabled={isPaying} variant="gradient" className="w-full h-12 font-bold">
                        {isPaying ? 'Verifying...' : 'I Have Paid ✅'}
                      </Button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>

          {/* Sidebar Summary */}
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }} className="space-y-5">
            <Card className="sticky top-28 bg-white/5 border-white/10">
              <CardContent className="p-6 space-y-5">
                <h3 className="font-display font-semibold text-xl">Order Summary</h3>

                {/* Platform badge */}
                <div className={`flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r ${platform.color} bg-opacity-10`}>
                  <span className="text-2xl">{platform.icon}</span>
                  <div>
                    <p className="font-semibold text-white text-sm">{platform.id}</p>
                    <p className="text-white/70 text-xs">{service}</p>
                  </div>
                </div>

                <div className="space-y-3 text-sm">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Quantity</span>
                    <span className="text-white font-medium">{Number(qty).toLocaleString() || 0}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Rate</span>
                    <span className="text-white font-medium">₦{PRICE_PER_UNIT}/unit</span>
                  </div>
                </div>

                <div className="h-px bg-white/10" />

                <div className="space-y-2">
                  <div className="flex justify-between text-muted-foreground text-sm">
                    <span>Subtotal</span>
                    <span>₦{originalPrice.toLocaleString()}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-green-400 font-medium text-sm">
                      <span>Discount (SAVE10)</span>
                      <span>-₦{discount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-2xl font-black font-display pt-1 text-white">
                    <span>Total</span>
                    <span>₦{totalPrice.toLocaleString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Referral */}
            <div className="p-4 rounded-2xl border border-dashed border-primary/30 bg-primary/5">
              <p className="text-primary font-medium text-sm mb-1">🎁 Earn Free Growth</p>
              <p className="text-xs text-muted-foreground mb-3">Share your code. Friends who order get you 10% off.</p>
              <div className="flex items-center justify-between bg-black/40 px-3 py-2 rounded-xl font-mono text-sm text-white border border-white/10">
                REF12345
                <button onClick={copyRef} className="text-primary hover:text-white transition-colors ml-2">
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
