import { useState, useEffect, useRef } from "react";
import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Header } from "@/components/layout/header";
import { Background } from "@/components/layout/background";
import { ChatWidget } from "@/components/chat-widget";
import { SettingsProvider } from "@/context/settings-context";
import HomePage from "@/pages/home";
import OrderPage from "@/pages/order";
import AuthPage from "@/pages/auth";
import DashboardPage from "@/pages/dashboard";
import WalletPage from "@/pages/wallet";
import NotFound from "@/pages/not-found";
import { useToast } from "@/hooks/use-toast";

const queryClient = new QueryClient();

interface User {
  name: string;
  email: string;
}

function AppRoutes() {
  const { toast } = useToast();
  const chatRef = useRef<{ open: () => void } | null>(null);

  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem('bestgrow_user');
    if (stored) {
      const parsed = JSON.parse(stored);
      return { name: parsed.name, email: parsed.email };
    }
    return null;
  });
  const [, navigate] = useLocation();

  useEffect(() => {
    const stored = localStorage.getItem('bestgrow_user');
    if (stored) {
      const parsed = JSON.parse(stored);
      const firstName = parsed.name?.split(' ')[0] || 'there';
      toast({
        title: `Welcome back, ${firstName}! 👋`,
        description: 'Great to see you again. Ready to grow?',
      });
    }
  }, []);

  const handleAuth = (u: User) => {
    setUser(u);
    navigate('/dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    navigate('/');
  };

  const openChat = () => {
    chatRef.current?.open();
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Background />
      <Header user={user} onLogout={handleLogout} onOpenChat={openChat} />
      <div className="flex-1 flex flex-col">
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/auth">
            {user ? <DashboardPage user={user} onLogout={handleLogout} /> : <AuthPage onAuth={handleAuth} />}
          </Route>
          <Route path="/dashboard">
            {user ? <DashboardPage user={user} onLogout={handleLogout} /> : <AuthPage onAuth={handleAuth} />}
          </Route>
          <Route path="/order">
            {user ? <OrderPage user={user} /> : <AuthPage onAuth={handleAuth} />}
          </Route>
          <Route path="/wallet">
            {user ? <WalletPage user={user} /> : <AuthPage onAuth={handleAuth} />}
          </Route>
          <Route component={NotFound} />
        </Switch>
      </div>
      <ChatWidget ref={chatRef} />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SettingsProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <AppRoutes />
          </WouterRouter>
          <Toaster />
        </SettingsProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
